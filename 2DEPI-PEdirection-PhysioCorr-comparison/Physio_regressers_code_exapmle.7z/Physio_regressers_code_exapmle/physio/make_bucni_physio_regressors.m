function [cardiac,respire,hrrv]=make_bucni_physio_regressors(physiofile,nslices,ndummies,refslice,channels)
     
% make_bucni_physio_regressors is a function for creating regressors,
% tailored for BUCNI data acquisition. The resulting regressors can 
% be included in SPM design matrices.  
%
% FORMAT [cardiac,respire,hrrv]=
%         make_bucni_physio_regressors(physiofile,nslices,
%         ndummies,refslice,channels)
%
% See physio_readme.txt and references below for a more complete
% description of inputs, outputs and methods
%
% Inputs: 
%        physiofile - full name and path daq file
%        nslices - number of slices in the volume
%        ndummies - number of dummy scans 
%        refslice - number of slice to which regressors will be interpolated       
%        channels - channel numbers in following order [scanner TTL resp1 resp2]
% 
% Outputs:
%        cardiac - cardiac phase regressors. This is an array of N scans x 10 
%                  regressors calculated from the TTL pulse.
%        respire - respiratory phase regressors. This is an array  
%                  of N scans x 6 regressors calculated from the respiratory belt.
%        hrrv    - heart rate and respiratory volume per unit time.
%                  The is an array of N scans x 2 regressors
%
% NB:  The routine filter_respiratory, called by this function, tries to use the 
%      matlab function butter from the Matlab Signal Processing toolbox. 
%      If it can't find it, it will ask the use
%      to select a matfile containing the coefficients. A default matfile
%      is distributed with the code (butter_2_10_100.mat). This contains
%      coefficients calculated for 2nd order high pass filter for a sampling 
%      interval of 100Hz, and a cutoff period of 10s. There are two sets
%      of coefficients called a and b, each a [1x3] sized vector.
%
%_______________________________________________________________________
% Refs and Background reading:
% 
% The implementation of this toolbox is described in:
% Hutton et al, 2011, NeuroImage.
% 
% The methods are based on the following:
% Glover et al, 2000, MRM, (44) 162-167 
% Josephs et al, 1997, ISMRM, p1682
% Birn et al, 2006, NeuroImage, (31) 1536-1548
%
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2007)

%  Chloe Hutton 
% $Id: make_bucni_physio_regressors.m 287 2011-12-15 17:08:23Z chloe $

%--------------------------------------------------------------------------
% Read all the physio data and sample rate from file
data = daqread(physiofile);

% Get channel numbers
scanner_channel = channels(1);
cardiac_channel = channels(2);
resp_channel1=channels(3);
resp_channel2=channels(4);

scanner = data(:,scanner_channel);
cardiac = data(:,cardiac_channel);
resp1 = data(:,resp_channel1);
resp2 = data(:,resp_channel2);
daqinfo = daqread(physiofile,'info');
samplerate = daqinfo.ObjInfo.SampleRate;

% EDITING IS REQUIRED HERE!!!

% The input data must be organised as follows:

% allscannert - Vector of increasing time stamps (in seconds) for each slice acquired in the run
%               i.e. time difference between consective time stamps equals the time to acquire a slice.
% allslices   - Vector of incremental slice numbers corresponding to the time stamps 
%               i.e. usually [1:number_of_volumes*slices_per_volume], but can be
%               adjusted if physiological monitoring started after scanning started
% allcpulset  - Vector of time stamps (in seconds) for cardiac pulse  
% allresp     - Vector containing respiratory waveform measured from time=0
%               seconds with sampling interval = rsampint seconds
% rsampint    - Sampling interval for respiration waveform (in seconds)
% nslices     - number of slices in a volume
% ndummies    - number of dummy volumes to be skipped at the beginning of the acquisition 
% refslice    - reference slice number

% Extract scanner pulses  - MAY NEED TO EDIT THIS!!
thresh = 4e-3;
allscannert = find(diff(scanner)>thresh);
% What are these time points in seconds?
allslices=[1:size(allscannert,1)];

% Extract cardiac pulses - MAY NEED TO EDIT THIS!!
thresh = 2; % Check this
allcpulset = find(diff(cardiac)>thresh);

% Process respiration NB - THIS ASSUMES A CONSTANT SCANNER PULSE
% INTERVAL!!!
% Sample respiratory wave at scanner pulses
allrespt = resp1(allscannert);
% Sample rate is now that of scanner pulse:
rsampint=mean(diff(allscannert))/samplerate;

% need to convert scanner and cardiac pulses to seconds
allscannert=allscannert/samplerate;
allcpulset=allcpulset/samplerate;

[cardiac,cardiacqrs,respire,hrrv]=physio_regressors(allscannert,allslices,allcpulset,allrespt,rsampint,nslices,ndummies,refslice);
 

