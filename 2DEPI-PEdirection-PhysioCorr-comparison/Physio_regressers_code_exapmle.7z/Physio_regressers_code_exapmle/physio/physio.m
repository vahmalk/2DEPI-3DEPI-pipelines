function physio
%
% physio is an SPM wrapper function for creating regressors 
% from physiological monitoring files acquired using spike, that
% can be included in SPM design matrices.
%
% FORMAT physio
%
% This wrapper function requires and does the following:
% 1) Enter the number of slices per volume, number of dummy volumes, 
%    slice TR (in ms), number of scan sessions included in the file (where 
%    starting and stopping the scanner for an EPI run while spike is recording 
%    physio data comprises one session - even if the data wasn't useful) and 
%    slice of interest to which regressors should be sampled.
% 2) The slice of interest should be one that contains a particular region of 
%    interest and is likely to be badly affected by physiological noise. Identify 
%    it by displaying one of the original fMRI images using the display button 
%    in SPM. The slice number will be the z voxel coordinate (NOT the mm coordinate).
% 3) Select the spike file which should be in the binary .smr format.
% 4) Select the appropriate channel names from the ones extracted from the spike 
%    file. Identify the channels of interest for the measured signals otherwise 
%    select 'None'.
% 5) The physiological regressors are constructed and the results saved in 
%    matlab files in the same directory as the spike file.
% 6) Each set of regressors from each scanning session are saved as a separate file 
%    as follows:
%    cardiac_sess - regressors modelling cardiac phase from pulse oximeter TTL pulse. 
%    This is an (N scans x 10) array. The 10 columns contain the 1st to 5th order 
%    Fourier series (5 sines and 5 cosines) modelling the measured cardiac phase. 
%    The result for each session is saved with the name spikefilename_cardiac_sessionX.mat.
%    cardiacqrs_sess - currently disabled
%    respire_sess - regressors modelling respiratory phase from respiratory belt signal. 
%    This is an (Nscans x 6) array. The 6 columns contain the 1st, 2nd and 3rd order 
%    Fourier series (3 sines and 3 cosines) modelling the measured respiratory phase. 
%    The result for each session is saved with the name spikefilename_respire_sessionX.mat.
%    rvt_sess - 2 regressors modelling the change in respiratory volume per unit time and the
%    heart rate. This is a an (Nscans x 2) array. The file is saved with the name     
%    spikefilename_rvt_sessionX.mat. 
% 7) The different regressors for each session are also saved together in an 
%    (Nscans x nregressors) array called R. This is saved with the filename filename_R_sessionN.mat 
%    which can be easily loaded under the Multiple Regressors option in SPM to include in a design matrix.
%    By default nregressors=14, 6 for cardiac, 6 for respiration and 2 for
%    heart rate and change in respiratory volume (see  Hutton et al, 2011, NeuroImage).
% 8) A file called 'spikefilename'_physioparams.mat is also saved that
%    contains the parameters used to construct the regressors.
%_______________________________________________________________________
% Refs and Background reading:
% 
% The implementation of this toolbox is described in:
% Hutton et al, 2011, NeuroImage.
% 
% The methods are based on the following:
% Glover et al, 2000, MRM, (44) 162-167 
% Josephs et al, 1997, ISMRM, p1682
% Birn et al, 2006, NeuroImage, (31) 1536-1548
%
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2008)
%  Chloe Hutton and Eric Featherstone
% $Rev: 404 $ $Date: 2024-01-24 15:46:32 +0000 (Wed, 24 Jan 2024) $

global nslices

% Collect inputs
spikelibdir = fullfile(fileparts(which(mfilename)),'son');
addpath(spikelibdir);
nslices = spm_input('Number of slices per volume',1,'r','48',[1 1]);
ndummies = spm_input('Number of dummy volumes',2,'r','5',[1 1]);
TR = spm_input('Slice TR (in ms)',3,'r','65',[1 1]);
TRms = TR; % TR in milliseconds for saving
TR = TR*1e-3; % TR in seconds
slicenum = spm_input('Slice of interest',4,'r','24',[1 1]);
% Do correction for slice order
orderopts={'ascending','descending','interleaved'};
sliceorderidx = spm_input('Slice order (default=ascending)',5,'m',orderopts);
sliceorder=orderopts{sliceorderidx};
slicenum = get_slicenum(slicenum,nslices,sliceorder);
nsessions = spm_input('Number of sessions in file',6,'r','1',[1 1]);
% Select physio file for reading
physiofile = spm_select(1,'^*\.smr$','Select a physio file');

% Pull out channel names from physio file
fid = fopen(physiofile);
channels = SONChanList(fid);
nchannels = size(channels,2);
channel=cell(1,nchannels);
for chnum=1:nchannels
   channel{chnum}=channels(chnum).title;
end
channel{chnum+1}='None';

str   = 'Select channel for scanner pulses';
scanner_channel_idx = spm_input(str,1,'m',channel);
if strcmp(channel{scanner_channel_idx},'None')
   error('Sorry. The scanner channel is required');
else 
  scanner_channel = channels(scanner_channel_idx).number;
end

str   = 'Select channel for cardiac (TTL) pulses';
cardiacTTL_channel_idx = spm_input(str,2,'m',channel);
if strcmp(channel{cardiacTTL_channel_idx},'None')
   cardiacTTL_channel = [];
else
   cardiacTTL_channel = channels(cardiacTTL_channel_idx).number;
end

str   = 'Select channel for cardiac (QRS) pulses';
cardiacQRS_channel_idx = spm_input(str,2,'m',channel);
if strcmp(channel{cardiacQRS_channel_idx},'None')
   cardiacQRS_channel = [];
else
   cardiacQRS_channel = channels(cardiacQRS_channel_idx).number;
end

str   = 'Select channel for respiration';
resp_channel_idx = spm_input(str,3,'m',channel);
if strcmp(channel{resp_channel_idx},'None')
   resp_channel = [];   
else
   resp_channel = channels(resp_channel_idx).number;
end

% Run main code
[cardiac,cardiacqrs,respire,rvt]=make_physio_regressors(physiofile,nslices,ndummies,TR,...
                slicenum,nsessions,scanner_channel,cardiacTTL_channel,cardiacQRS_channel,resp_channel);                   

% Save a record of parameters used for the regressors
%eval(['save ' spm_str_manip(physiofile,'r') '_physioparams physiofile nslices ndummies TRms slicenum nsessions']);
filename=[spm_str_manip(physiofile,'r'), '_physioparams'];
save(filename, 'physiofile', 'nslices', 'ndummies', 'TRms','slicenum','nsessions','sliceorder');

% For each session, put regressors in a matrix called R and save with the name 
% 'physiofile_R_session%d'. 
% This file can be loaded into an SPM design matrix using the 'Multiple Regressors' option.
% NB if you also want to include motion parameters as regressors of no interest, you 
% could also put them in R.
for sessnum=1:nsessions
   R=[];
   if ~isempty(cardiac{sessnum})
      cardiac_sess = cardiac{sessnum};
      filename = sprintf('%s_cardiac_session%d',spm_str_manip(physiofile,'r'),sessnum);
      save(filename, 'cardiac_sess');      
      R=cat(2,R,cardiac{sessnum}(:,1:6));
   end
   if ~isempty(cardiacqrs{sessnum})
      cardiacqrs_sess = cardiacqrs{sessnum};
      filename = sprintf('%s_cardiacqrs_session%d',spm_str_manip(physiofile,'r'),sessnum); 
      save(filename, 'cardiacqrs_sess');
      R=cat(2,R,cardiacqrs{sessnum});
   end
   if ~isempty(respire{sessnum})
      respire_sess = respire{sessnum};
      filename = sprintf('%s_respire_session%d',spm_str_manip(physiofile,'r'),sessnum); 
      save(filename, 'respire_sess');
      R=cat(2,R,respire{sessnum}(:,1:6));
   end
   if ~isempty(rvt{sessnum})
      rvt_sess = rvt{sessnum};
      filename = sprintf('%s_rvt_session%d',spm_str_manip(physiofile,'r'),sessnum); 
      save(filename,'rvt_sess');
      R=cat(2,R,rvt{sessnum}(:,1:2));
   end
   if ~isempty(R)
       % Save R for all physio only
       nfiles=size(R,1);
       oR=R;
       Rname = sprintf('%s_R_session%d',spm_str_manip(physiofile,'r'),sessnum);
       R=R-repmat(mean(R),nfiles,1);
       save(Rname, 'R');
   end
end
