% physio_raw_data_script.m
%
% Script that calls physio routines to construct physiological regressors
% from raw physiological data. 
%
% The physio toolbox was originally written for in-house use at the WTCN
% with physiological files acquired using spike. This script describes how 
% more generic physiological data can be processed using the physio toolbox.
% The file 'physio_raw_data_example.mat' contains example data to
% demonstrate how generic physiological data should be organised.
%
% Description of scanner synchronised physiological data
% ******************************************************
% Input data should be synchronized with time=0 seconds corresponding to
% the start of measurements.
%
% allscannert - Vector of increasing time stamps (in seconds) for each slice acquired in the run
%               i.e. time difference between consective time stamps equals the time to acquire a slice.
% allslices   - Vector of incremental slice numbers corresponding to the time stamps 
%               i.e. usually [1:number_of_volumes*slices_per_volume], but can be
%               adjusted if physiological monitoring started after scanning started
% allcpulset  - Vector of time stamps (in seconds) for cardiac pulse  
% allresp     - Vector containing respiratory waveform measured from time=0
%               seconds with sampling interval = rsampint seconds
% rsampint    - Sampling interval for respiration waveform (in seconds)
% nslices     - number of slices in a volume
% ndummies    - number of dummy volumes to be skipped at the beginning of the acquisition 
% slicenum    - reference slice number
%
% NB This script is for demonstration purposes and may need editing in order
% to generate the required regressors.
%
% See physio_readme.txt and references below for a more complete
% description of inputs, outputs and methods
%_______________________________________________________________________
% Refs and Background reading:
% 
% The implementation of this toolbox is described in:
% Hutton et al, 2011, NeuroImage.
% 
% The methods are based on the following:
% Glover et al, 2000, MRM, (44) 162-167 
% Josephs et al, 1997, ISMRM, p1682
% Birn et al, 2006, NeuroImage, (31) 1536-1548
%
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2010)
% Chloe Hutton
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

load physio_raw_data_example

% Can make a plot of the raw physio data.
% This shows the respiration wave form (blue) with the time points of
% cardiac pulses (red) and scanner pulses (green).
% figure
% hold on
% plot([0:size(allresp,1)-1]*rsampint,(allresp/20)-mean(allresp/20));
% stem(allcpulset,ones(size(allcpulset))*2,'r*');
% stem(allscannert,ones(size(allscannert)),'g*');
% grid on

[cardiac,cardiacqrs,respire,hrrv]=physio_regressors(allscannert,allslices,allcpulset,allresp,rsampint,nslices,ndummies,slicenum);
 
R=[cardiac(:,1:6) respire hrrv];
R=R-repmat(mean(R),size(R,1),1);
save R R
