% physio_script.m
% Script that calls physio routines to construct physiological regressors
% acquired using the spike data acquisition software.
% This script is for demonstration purposes and may need editing in order
% to generate the required regressors.
% The main routine to create the physio regressors is make_physio_regressors
%
%_______________________________________________________________________
% Refs and Background reading:
% 
% The implementation of this toolbox is described in:
% Hutton et al, 2011, NeuroImage.
% 
% The methods are based on the following:
% Glover et al, 2000, MRM, (44) 162-167 
% Josephs et al, 1997, ISMRM, p1682
% Birn et al, 2006, NeuroImage, (31) 1536-1548
%
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2010)
%
% Chloe Hutton
% $Rev: 403 $ $Date: 2024-01-24 15:04:06 +0000 (Wed, 24 Jan 2024) $

% Add necessary folders to path
[spm_path, name] = fileparts(which('spm'));
physiopath       = sprintf('%s%s%s%s%s',spm_path,filesep,'toolbox',filesep,'physio');
addpath(physiopath);
sonpath          = sprintf('%s%s%s%s%s%s%s',spm_path,filesep,'toolbox',filesep,'physio',filesep,'son');
addpath(sonpath);

global nslices     % (required by readslices in volume trigger mode)

% Add name of physio file
% physiofile = 'D:\test111\LC_fMRI\physio_code\2DEPI_AP_run.smr';
physiofile = 'D:\test111\LC_fMRI\physio_code\M700860\restricted_PA_run2.smr';

% Input values that must be defined correctly for specific acquisition
nslices   = 78/3;     % Number of slices in volume
ndummies  = 0;      % Number of scans excluded from analysis
TR        = 2.1/nslices;  % Slice TR in secs
TRms      = TR*1e3; % As above
nsessions = 1;      % Number of scanning sessions in the file

slicenum  = floor(nslices/2);     % Slice number to time-lock regressors to
% slicenum  = 48/3;     % Slice number to time-lock regressors to
% The above slice number can be determined from
% data converted to nifti format. By default, slices
% will be numbered from bottom to top but the acquisition
% order can be ascending, descending or interleaved.
% If slice order is descending or interleaved, the slice number
% must be adjusted to represent the time at which the slice of
% interest was acquired:
sliceorder = 'interleaved'; % Ascending by default. 
slicenum   = get_slicenum(slicenum,nslices,sliceorder);

% The channel numbers must be assigned as they have been in spike.
% Unused channels should be set to empty using [];
% The channel numbers can be checked using the routines 
% show_channels and check_channels as demonstrated below.
% Once the channels have been set correctly, they should
% stay the same when using spike with the same set-up and
% configuration file.

show_channels(physiofile);
scanner_channel     = 1;
cardiacTTL_channel  = 2;
cardiacQRS_channel  = []; % currently disabled
resp_channel        = 4;
check_channels(physiofile,scanner_channel,cardiacTTL_channel,cardiacQRS_channel,resp_channel);

% Call the main routine for calculating physio regressors
% NB - currently the cardiacqrs calculation is disabled.
[cardiac,cardiacqrs,respire,rvt] = make_physio_regressors(physiofile,nslices,ndummies,TR,...
                slicenum,nsessions,scanner_channel,cardiacTTL_channel,cardiacQRS_channel,resp_channel);               
   
% Save a record of parameters used for the regressors
%eval(['save ' spm_str_manip(physiofile,'r') '_physioparams physiofile nslices ndummies TRms slicenum nsessions']);
filename=[spm_str_manip(physiofile,'r'), '_physioparams'];
save(filename, 'physiofile', 'nslices', 'ndummies', 'TRms','slicenum','nsessions','sliceorder');

% Save a record of parameters used for the regressors
%eval(['save ' spm_str_manip(physiofile,'r') '_physioparams physiofile nslices ndummies TRms slicenum nsessions']);
filename=[spm_str_manip(physiofile,'r'), '_physioparams'];
save(filename, 'physiofile', 'nslices', 'ndummies', 'TRms','slicenum','nsessions','sliceorder');

% For each session, put regressors in a matrix called R.
% Each individual set of regressors are saved and also all regressors are saved with the name 'physiofile_R_session%d'. 
% These files can be loaded into an SPM design matrix using the 'Multiple Regressors' option.
% NB motion parameters can also be concatenated with the physio regressors 
% and saved as a set of regressors called R (see below for example)

for sessnum=1:nsessions
   R=[];
   if ~isempty(cardiac{sessnum}) && ~isempty(cardiac{sessnum})
      cardiac_sess = cardiac{sessnum};
      filename = sprintf('%s_cardiac_session%d',spm_str_manip(physiofile,'r'),sessnum);
      save(filename, 'cardiac_sess');    
      R=cat(2,R,cardiac{sessnum}(:,1:6));
   end
   if ~isempty(cardiacqrs{sessnum}) && ~isempty(cardiacqrs{sessnum})
      cardiacqrs_sess = cardiacqrs{sessnum};
      filename = sprintf('%s_cardiacqrs_session%d',spm_str_manip(physiofile,'r'),sessnum); 
      save(filename, 'cardiacqrs_sess');
      R=cat(2,R,cardiacqrs{sessnum}(:,1:6));
   end
   if ~isempty(respire) && ~isempty(respire{sessnum})
      respire_sess = respire{sessnum};
      filename = sprintf('%s_respire_session%d',spm_str_manip(physiofile,'r'),sessnum); 
      save(filename, 'respire_sess');
      R=cat(2,R,respire{sessnum}(:,1:6));
   end
   if ~isempty(rvt) && ~isempty(rvt{sessnum})
      rvt_sess = rvt{sessnum};
      filename = sprintf('%s_rvt_session%d',spm_str_manip(physiofile,'r'),sessnum); 
      save(filename,'rvt_sess');
      R=cat(2,R,rvt{sessnum}(:,1:size(rvt{sessnum},2)));
   end
   nfiles=size(R,1);
   % Save R for all physio only 
   if nfiles>0
      oR=R;
      Rname = sprintf('%s_R_session%d',spm_str_manip(physiofile,'r'),sessnum);
      R=R-repmat(mean(R),nfiles,1);
      save(Rname, 'R');
   end
%    If required, also concatenate with motion params, e.g.
%  load rp_example.txt
%   RP=rp_example;
%   R=cat(2,oR,RP); 
%   R=R-repmat(mean(R),nfiles,1);
%   Rname = sprintf('%s_R_session%d',spm_str_manip(physiofile,'r'),sessnum);
%   save(Rname, 'R');   
end
