function [cardiac,cardiacqrs,respire,hrrv]=make_magphysio_regressors(physiofile,nslices,ndummies,refslice,scanner_channel,...
         co2_channel,cardiac_channel,resp_channel)
% make_physio_regressors is a function for creating regressors 
% from physiological monitoring files acquired using spike, that
% can be included in SPM5 design matrices.
%
% FORMAT [cardiac,cardiacqrs,respire,rvt]=
%         make_physio_regressors(physiofile,nslices,
%         ndummies,TR,slicenum,nsessions,scanner_channel,cardiacTTL_channel,cardiacQRS_channel,resp_channel)
%
% Inputs: 
%        physiofile - full name and path of spike .smr file
%        nslices - number of slices in the volume
%        ndummies - number of dummy scans 
%        TR - slice TR in seconds
%        slicenum - number of slice to which regressors will
%                   be interpolated
%        nsessions - number of scanning sessions recorded in the file
%        scanner_channel - spike channel number for scanner pulses
%        cardiacTTL_channel - spike channel number for cardiac TTL pulses
%        cardiacQRS_channel - spike channel number for cardiac QRS pulses
%        resp_channel - spike channel number for respiratory belt data
% 
% Outputs:
%        cardiac - cardiac phase regressors. This is a 1 x nsessions cell 
%                  array where each cell contains regressors of (N scans x 10) 
%                  calculated from the TTL pulse.
%        cardiacqrs - currently disabled.
%        respire - respiratory phase regressors. This is a 1 x nsessions cell 
%                  array where each cell contains regressors 
%                  of (N scans x 6) calculated from the respiratory belt.
%        rvt - respiratory volume per unit time. This is a 1 x nsessions cell 
%              array where each cell contains regressors 
%              of (N scans x 1) calculated from the respiratory phase.
%
% NB:  The routine filter_respiratory, called by this function, tries to use the 
%      matlab function butter from the Matlab Signal Processing toolbox. 
%      If it can't find it, it will ask the use
%      to select a matfile containing the coefficients. A default matfile
%      is distributed with the code (butter_2_10_100.mat). This contains
%      coefficients calculated for 2nd order high pass filter for a sampling 
%      interval of 100Hz, and a cutoff period of 10s. There are two sets
%      of coefficients called a and b, each a [1x3] sized vector.
%
%_______________________________________________________________________
% Refs and Background reading:
% 
% The code to model the cardiac and respiratory signal is based on the 
% following references
% Glover et al, 2000, MRM, (44) 162-167 
% Josephs et al, 1997, ISMRM, p1682
% The code to model the change in respiratory volume per unit time is based
% on the following reference:
% Birn et al, 2006, NeuroImage, (31) 1536-1548
%_______________________________________________________________________
% make_physio_regressors.m     Eric Feathersone and Chloe Hutton 02/06/08 
% 

%--------------------------------------------------------------------------
% Read all the physio data and sample rate from file
data = daqread(physiofile);
scanner = data(:,scanner_channel);
c02 = data(:,co2_channel);
cardiac = data(:,cardiac_channel);
resp = data(:,resp_channel);
daqinfo = daqread(physiofile,'info');
samplerate = daqinfo.ObjInfo.SampleRate;

% Extract scanner pulses and slice numbers
thresh = 0.9;
scannert = find(scanner(1:end-1)<thresh & scanner(2:end)>thresh);
slices=[1:size(scannert,1)];
nscans=round(slices/nslices);

% Extract time point (rising edge) for each cardiac pulses
ncardiac=cardiac-mean(cardiac);
scardiac=zeros(size(cardiac));

% Smooth over 1/10 seconds (i.e. samplerate/10 points)
cardiac_fwhm=samplerate/10;
spm_smooth(ncardiac,scardiac,cardiac_fwhm);
cardiact=find(scardiac(1:end-1)<0 & scardiac(2:end)>=0);

% Process respiration
% Sample respiratory wave at scanner pulses
respt = resp(scannert);
% Sample rate is now that of scanner pulse:
sampint=mean(diff(scannert))/samplerate;

% need to make cardiact in seconds
cardiact=cardiact/samplerate;
scannert=scannert/samplerate;

%[cardiac{sessnum},cardiacqrs{sessnum},respire{sessnum},hrrv{sessnum}]=physio_regressors(allscannert{sessnum},allslices{sessnum},allcpulset{sessnum},allrpulset{sessnum},rsampint,nslices,ndummies,slicenum);

[cardiac,cardiacqrs,respire,hrrv]=physio_regressors(scannert,slices,cardiact,respt,sampint,nslices,ndummies,refslice);


% % Check we've correctly identified rising edges
% % figure
% % hold on
% % plot(cardiac);
% % plot(cardiact,ones(size(cardiact))*mean(cardiac),'r*');
% 
% % Fit fourier series to cardiac phase
% cardiacfit = fit_cardiac(cardiact,scannert);
% % Down sample cardiac phase to volumes
% cardiacfitvol=cardiacfit(((ndummies*nslices)+refslice):nslices:end,:);
% 
% % Calculate cardiac rate and convert to beats-per-minute
% hrvol = heart_rate(cardiact,scannert,ndummies,nslices,refslice,samplerate);
% 
% % Process respiration
% % Sample respiratory wave at scanner pulses
% respt = resp(scannert);
% % Sample rate is now that of scanner pulse:
% sampint=mean(diff(scannert))/samplerate;
% fresp = filter_respiratory(respt,sampint);
% respfit=fit_respiratory(respt,sampint);
% 
% % Down sample respiratory
% respfitvol=respfit(((ndummies*nslices)+refslice):nslices:end,:);
% % Calculate RVT
% %rvt = resp_var(fresp,sampint);
% rvt = resp_var(respt,sampint);
% 
% % Convolve with IRF 
% rv=resp_IRF(rvt,sampint);
% rvvol=rv(((ndummies*nslices)+refslice):nslices:end);
% rvvol=2*rvvol/(max(rvvol)-min(rvvol));
