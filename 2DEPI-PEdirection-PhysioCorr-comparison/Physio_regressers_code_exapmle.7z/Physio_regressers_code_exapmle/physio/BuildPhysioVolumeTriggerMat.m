%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    BuildPhysioVolumeTriggerMat regressors for physio files with only one
%    trigger per volume
%    NC 11.04.18
%    PhysioFile:   Physio file (mat format)
%    TotalNbSlice: Total nb of slices acquired per volume
%    ndummies:     Number of dummy scans to discard at the beginning
%    slicenum:     Reference slice number
%
%   The matrix of regressors will be written into the folder of the mat
%   file, with the suffix _R
%
%  Example:  R=BuildPhysioVolumeTriggerMat('007run1.mat',48,0,24)
%
%  $Rev: 401 $ $Date: 2024-01-23 17:52:05 +0000 (Tue, 23 Jan 2024) $
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [R]=BuildPhysioVolumeTriggerMat (PhysioFileName,TotalNbSlices,ndummies,slicenum)

%% Port numbers
%%% Default values currently in place at the FIL (should be changed if another setup is used)
scanner_channel   = 1;
cardiacTTL_channel= 2;
resp_channel      = 4;

%% Load Physio Files
S=load(PhysioFileName);
Fields=fieldnames(S);

%% which filed corresponds to the scanner triggers ?
k=1;
while (Fields{k}(end)~=num2str(scanner_channel))
    k=k+1;
end
Trig=Fields{k};
Trig_times=S.(Trig).times;
Trig_times_pos=Trig_times(1:2:end); % Only Positive trig
VolumeTR=(Trig_times_pos(11)-Trig_times_pos(1))/10;
SliceTR=VolumeTR/TotalNbSlices;

%% Artificals triggers are added between real triggers
%%%  to simulate slices.
allscannert=(interp1(1:TotalNbSlices:TotalNbSlices*length(Trig_times_pos),Trig_times_pos,1:1:TotalNbSlices*length(Trig_times_pos)));
allscannert((length(Trig_times_pos)*TotalNbSlices)-TotalNbSlices+2:end)= allscannert((length(Trig_times_pos)*TotalNbSlices-TotalNbSlices+1))+SliceTR*(1:TotalNbSlices-1);%% triggers for the slice s of the last volume
allscannert=allscannert';



%% Cardiac traces
k=1;
while (Fields{k}(end)~=num2str(cardiacTTL_channel))
    k=k+1;
end
Pulse=Fields{k};
Pulse_times=S.(Pulse).times;
allcpulset=Pulse_times;
cpulset=get_cardiac(allscannert,allcpulset);
%% Respiration traces
k=1;
while (Fields{k}(end)~=num2str(resp_channel))
    k=k+1;
end
Resp=Fields{k};
Resp_values=S.(Resp).values;
Resp_int=S.(Resp).interval;

allslices=1:length(allscannert);
allrpulset=Resp_values;
rsampint=Resp_int;
rpulset=get_respiratory(allscannert,allrpulset,rsampint);


%% Build regressors

[cardiac,cardiacqrs,respire,hrrv]=physio_regressors(allscannert,allslices,cpulset{1},rpulset{1},rsampint,TotalNbSlices,ndummies,slicenum);


%% Save matrix of physio regresors
R=[cardiac(:,1:6) respire hrrv];
R=R-repmat(mean(R),size(R,1),1);

[pn, fn]=fileparts(PhysioFileName);
save(fullfile(pn,strcat(fn,'_R.mat')),'R')