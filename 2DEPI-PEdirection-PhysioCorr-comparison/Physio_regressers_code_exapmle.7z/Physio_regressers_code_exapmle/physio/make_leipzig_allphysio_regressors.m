function [cardiacfit cardiacfitvol respt respfit respfitvol rvvol hrvol co2tvol etco2vol o2tvol meano2vol mino2vol maxo2vol metabo2vol eto2vol resprate_co2vol resprate_o2vol]=make_leipzig_allphysio_regressors(physiofile,TR,nslices,ndummies,refslice,scanner_channel,...
         cardiac_channel,respbelt_channel,resp_channel,delay_co2,delay_o2,display_plots)
% make_leipzigphysio_regressors is a function for creating regressors 
% from physiological monitoring files acquired using BIOPAC system at Leipzig, that
% can be included in SPM5/SPM8 design matrices.
%
% FORMAT [cardiacfit,cardiacfitvol,respt,respfit,respfitvol,rvvol,hrvol,
%         co2tvol,etco2vol,o2tvol,meano2vol,mino2vol,maxo2vol,metabo2vol,
%         resprate_co2vol,resprate_o2vol]=
%         make_leipzigphysio_regressors(physiofile,TR,nslices,ndummies,
%         refslice,scanner_channel,cardiac_channel,resp_channel)
%
% Inputs: 
%        physiofile - full name and path of physio file
%        TR - slice TR in seconds
%        nslices - number of slices in the volume
%        ndummies - number of dummy scans
%        refslice - number of slice to which regressors will
%                   be interpolated
%        scanner_channel - spike channel number for scanner pulses
%        cardiac_channel - spike channel number for cardiac TTL pulses
%        resp_channel - spike channel number for respiratory belt data
%        delay - delay - only applied to the CO2 and O2
%
%_______________________________________________________________________
% make_leipzig_allphysio_regressors.m     Chloe Hutton 23/11/10 
% 
%--------------------------------------------------------------------------
% Read all the physio data and sample rate from file
data = load(physiofile); 
scanner = data.data(:,scanner_channel);
cardiac = data.data(:,cardiac_channel); 
% cardiac = data.data(1:10:end,cardiac_channel); %DI - trial
% cardiac_samplerate = 1000; %DI - trial
%%NEW%% - hopefully, the respiration belt data is simply in another
%%channel and this works....
respbelt=data.data(:,respbelt_channel);
%%END-NEW%%
resp = data.data(:,resp_channel);
co2_channel=2;
co2 = data.data(:,co2_channel);
o2_channel=3;
o2 = data.data(:,o2_channel);
resprate_co2_channel=10;
resprate_co2 = data.data(:,resprate_co2_channel);
resprate_o2_channel=9;
resprate_o2 = data.data(:,resprate_o2_channel);

% I backward engineered the sample rate from the 2 second TR :-)
samplerate = 10000; 

% Extract scanner pulses and slice numbers
scanner=max(scanner)-scanner;
thresh = 4.8; 
scannert = find(scanner(1:end-2)<thresh & scanner(2:end-1)>thresh & scanner(3:end)>thresh); 
% We know there are some missing pulses, so find last one and get total
nvols=round((scannert(end)-scannert(1))/(TR*samplerate));
slices=[1:(nvols*nslices)];
scannert=round((((slices-1)*TR/nslices*samplerate)+scannert(1))');

%%CH-NEW%% 
% NB - Code below doesn't work because cardiac needs to be down-sampled
% % Extract time point (rising edge) for each cardiac pulse
% ncardiac=cardiac-mean(cardiac);
% scardiac=zeros(size(cardiac));
% 
% % Smooth over 1/10 seconds (i.e. samplerate/10 points) % DI - CHECK and CHANGE THIS!!!
% % cardiac_fwhm=cardiac_samplerate/10; %DI - trial
% cardiac_fwhm=samplerate/10;
% spm_smooth(ncardiac,scardiac,cardiac_fwhm);
% cardiact=find(scardiac(1:end-1)<0 & scardiac(2:end)>=0);

%%CH-NEW%% - We need to down-sample cardiac so the smoothing works
% e.g. lets sample at 1kHz, i.e.e downsample is
% samplerate/newsamplerate=10;
newsamplerate=1000;
downsample=samplerate/newsamplerate;
cardiac=cardiac(1:downsample:end,1); % Downsample cardiac
ncardiac=cardiac-mean(cardiac);
scardiac=zeros(size(cardiac));

% % Smooth over 1/10 seconds (i.e. newsamplerate/10 points) 
cardiac_fwhm=newsamplerate/10; 
spm_smooth(ncardiac,scardiac,cardiac_fwhm);
cardiact=find(scardiac(1:end-1)<0 & scardiac(2:end)>=0);

% Check we've correctly identified rising edges
 figure
 hold on
 plot(cardiac);
 plot(cardiact,ones(size(cardiact))*mean(cardiac),'r*');

%%CH-NEW%% - Now cardiact contains cardiac pulses with a time constant
% of newsamplerate (it was samplerate before). Therefore, when we use
% scannert to sample cardiact, scannert also needs to be scaled by
% the downsample factor, i.e. scannert*downsample:

% Fit fourier series to cardiac phase
cardiacfit = fit_cardiac(cardiact,scannert/downsample);
% Down sample cardiac phase to volumes
cardiacfitvol=cardiacfit(((ndummies*nslices)+refslice):nslices:end,:);

% Calculate cardiac rate and convert to beats-per-minute
hrvol = heart_rate(cardiact,scannert,ndummies,nslices,refslice,samplerate);

%%CH-NEW%% - Just a comment... since the other physiological measures are
%still sampled at the the higher rate (e.g. samplerate), we can still use
% scannert to sample them.

%%NEW%% - this is my routine code for calculating and fitting respiratory
%%regressors - fingers crossed it will just work...:
% Sample respiratory wave at scanner pulses
respt = respbelt(scannert); %%CHECK THIS LOOKS FINE - IT SHOULD JUST BE A DOWN_SAMPLED VERSION OF BELT DATA!%%
% Sample rate is now that of scanner pulse:
sampint=mean(diff(scannert))/samplerate; %% ALSO CHECK THIS MAKES SENSE
fresp = filter_respiratory(respt,sampint);
respfit=fit_respiratory(respt,sampint);

% Down sample respiratory
respfitvol=respfit(((ndummies*nslices)+refslice):nslices:end,:);
% Calculate RVT
rvt = resp_var(respt,sampint);

% Convolve with IRF 
rv=resp_IRF(rvt,sampint);
rvvol=rv(((ndummies*nslices)+refslice):nslices:end);
rvvol=2*rvvol/(max(rvvol)-min(rvvol));
%%END-NEW%%

% ------------------------------------------------------------------------
% The next part deals with co2 values and etco2vals

% delay is in seconds so convert to scanner pulses
scandelay_co2=delay_co2/(TR/nslices);

% Add the delay to the scanner pulses used to sample the gas
dscannert_co2=[scannert(scandelay_co2+1:end);[scannert(end)+[1:scandelay_co2]*TR/nslices*samplerate]'];

%--------------------------------------------------------------------------
% CO2 and etCO2
%--------------------------------------------------------------------------
% Extract c02 values corresponding to scanner pulses
co2t = co2(dscannert_co2);
co2tvol=co2t(((ndummies*nslices)+refslice):nslices:end,:);

figure
hold on
plot(co2t,'r')

% Extract end-tidal values from the co2 trace:
co2t_fwhm=(nslices/TR);
nco2t=co2t-mean(co2t);
sco2t=zeros(size(nco2t));
spm_smooth(nco2t,sco2t,co2t_fwhm);
dsco2t=diff(sco2t);

% Now look for the zero crossings in dsco2 
zcross=find(dsco2t(1:end-1)>=0 & dsco2t(2:end)<=0);
% Now find the maximum between each zero crossing
mxzcross=[];
for nz=2:size(zcross,1)
    [mx,mxz]=max(co2t(zcross(nz-1):zcross(nz)));
    mxzcross(nz-1,1)=zcross(nz-1)+mxz-1;
end

% Assign etco2 values to volumes
for volnum=1:nvols
    startscan=(ndummies+volnum-1)*nslices+1;
    stopscan=startscan+nslices-1;
    n=find(mxzcross>=startscan & mxzcross<=stopscan);
    % If there are more than one value
    if size(n,1)==1
        etco2vol(volnum,1)=co2t(mxzcross(n));
    elseif size(n,1)>1
        etco2vol(volnum,1)=mean(co2t(mxzcross(n)));
    else
        etco2vol(volnum,1)=NaN;
    end
end

etco2vol=fix_nans(etco2vol);

if display_plots==1
figure
hold on
plot(co2tvol,'c')
plot(etco2vol,'r');
end

%--------------------------------------------------------------------------
% O2 and etO2
%--------------------------------------------------------------------------
% Extract o2 values corresponding to scanner pulses (after including the delay)

% delay is in seconds so convert to scanner pulses
scandelay_o2=delay_o2/(TR/nslices);

% Add the delay to the scanner pulses used to sample the gas
dscannert_o2=[scannert(scandelay_o2+1:end);[scannert(end)+[1:scandelay_o2]*TR/nslices*samplerate]'];

o2t = o2(dscannert_o2);

figure
    hold on
    plot(o2t,'r');

o2tvol=o2t(((ndummies*nslices)+refslice):nslices:end,:);

% Extract end-tidal values from the o2 trace:
% Mean correct and smooth O2 values
o2t_fwhm=(nslices/TR);
no2t=o2t-mean(o2t);
so2t=zeros(size(no2t));
spm_smooth(no2t,so2t,o2t_fwhm);
dso2t=diff(so2t);

% Now look for the zero crossings in dso2 
zcross=find(dso2t(1:end-1)>=0 & dso2t(2:end)<=0);
% Now find the max and mean between each zero crossing
mxzcross=[];
mnzcross=[];
for nz=2:size(zcross,1)
    [mx,mxz]=max(o2t(zcross(nz-1):zcross(nz)));
    mxzcross(nz-1,1)=zcross(nz-1)+mxz-1;
    [mn,mnz]=min(o2t(zcross(nz-1):zcross(nz)));
    mnzcross(nz-1,1)=zcross(nz-1)+mnz-1;
end
    
% Assign max, min and mean values to volumes
for volnum=1:nvols
    startscan=(ndummies+volnum-1)*nslices+1;
    stopscan=startscan+nslices-1;
    n=find(mxzcross>=startscan & mxzcross<=stopscan);
    % If there are more than one value
    if size(n,1)==1
        maxo2vol(volnum,1)=o2t(mxzcross(n));
        mino2vol(volnum,1)=o2t(mnzcross(n));
    elseif size(n,1)>1
        maxo2vol(volnum,1)=mean(o2t(mxzcross(n)));
        mino2vol(volnum,1)=mean(o2t(mnzcross(n)));
    else
        maxo2vol(volnum,1)=NaN;
        mino2vol(volnum,1)=NaN;
    end
end

% Get rid of NaNs
maxo2vol=fix_nans(maxo2vol);
mino2vol=fix_nans(mino2vol);

% Calculate the meano2 (envelope) and the o2 metabolism 
meano2vol=(maxo2vol+mino2vol)/2;
metabo2vol=o2tvol-meano2vol;

% Calculate the derivatives of the curves for minO2 and maxO2

derivative_maxo2vol=diff(maxo2vol);
derivative_mino2vol=diff(mino2vol);


eto2vol=mino2vol;
switched_state=false;
threshold_DI = -10;
for i=1:size(derivative_maxo2vol,1)
 if(derivative_maxo2vol(i) < threshold_DI && derivative_mino2vol(i) < threshold_DI && ~switched_state)
     switched_state=true;
 end
 if(switched_state  && (derivative_maxo2vol(i) > threshold_DI*0.5) && (derivative_maxo2vol(i) > derivative_mino2vol(i)) )
     switched_state=false; % & (derivative_maxo2vol(i) > derivative_mino2vol(i))
 end;
 if(switched_state)
     eto2vol(i+1)=maxo2vol(i+1);
 end
end

    figure
    hold on
    plot(derivative_maxo2vol,'c');
    plot(derivative_mino2vol,'r');

if display_plots==1
    figure
    hold on
    plot(o2tvol,'c');
    plot(maxo2vol,'r');
    plot(mino2vol,'k');
    plot(eto2vol,'b');
end

%--------------------------------------------------------------------------
% Respiration rates
%--------------------------------------------------------------------------
% Extract resprate_c02 values corresponding to scanner pulses
resprate_co2t = resprate_co2(dscannert_co2);
resprate_co2vol=resprate_co2t(((ndummies*nslices)+refslice):nslices:end,:);

% Extract o2 values corresponding to scanner pulses
resprate_o2t = resprate_o2(dscannert_o2);
resprate_o2vol = resprate_o2t(((ndummies*nslices)+refslice):nslices:end,:);

if display_plots==1
    figure
    hold on
    plot(resprate_o2vol,'r')
    plot(resprate_co2vol,'b')
end