function show_channels(physiofile)
%________________________________________________________
% show_channels.m
% $Rev: 400 $ $Date: 2024-01-16 16:21:15 +0000 (Tue, 16 Jan 2024) $

if 0==exist(physiofile, 'file')
    error('Can not find or open file %s\n',physiofile);
end
fid = fopen(physiofile);
channels = SONChanList(fid);
nchannels = size(channels,2);
for ch=1:nchannels
   fprintf('Channel %d is called %s\n',channels(ch).number,channels(ch).title);
end
