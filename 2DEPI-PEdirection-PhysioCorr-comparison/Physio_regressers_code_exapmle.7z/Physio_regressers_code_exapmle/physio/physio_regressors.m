function [cardiac,cardiacqrs,respire,hrrv]=physio_regressors(allscannert,allslices,allcpulset,allresp,rsampint,nslices,ndummies,slicenum)
% physio_regressors is a function for creating regressors 
% from physiological monitoring data that can be included in SPM design matrices.
%
% FORMAT [cardiac,cardiacqrs,respire,rvt]=
%         physio_regressors(allscannert,allslices,allcpulset,allresp,rsampint,nslices,ndummies,slicenum)
%
% See physio_readme.txt and references below for a more complete
% description of inputs, outputs and methods
%
% Inputs: 
% 
% Input data should be synchronized with time=0 seconds corresponding to
% the start of measurements.
%
% allscannert - Vector of increasing time stamps (in seconds) for each slice acquired in the run
%               i.e. time difference between consective time stamps equals the time to acquire a slice.
% allslices   - Vector of incremental slice numbers corresponding to the time stamps, 
%               i.e. usually [1:number_of_volumes*slices_per_volume], but can be
%               adjusted if physiological monitoring started after scanning started
% allcpulset  - Vector of time stamps (in seconds) for cardiac pulse 
% allresp     - Vector containing respiratory waveform measured from time=0
%               seconds with sampling interval = rsampint seconds
% rsampint    - Sampling interval for respiration waveform (in seconds)
% nslices     - number of slices in a volume
% ndummies    - number of dummy volumes to be skipped at the beginning of the acquisition 
% slicenum    - reference slice number
%
% Outputs:
%        cardiac    - cardiac phase regressors. This is an array of N scans x 10 
%                     values calculated from the TTL pulse.
%        cardiacqrs - currently disabled.
%        respire    - respiratory phase regressors. This is an array N scans x 6
%                     calculated from the respiratory belt.
%        rvt        - respiratory volume per unit time and heart rate. This is an 
%                     array of N scans x 2.
%
% NB:  The routine filter_respiratory, called by this function, tries to use the 
%      matlab function butter from the Matlab Signal Processing toolbox. 
%      If it can't find it, it will ask the use
%      to select a matfile containing the coefficients. A default matfile
%      is distributed with the code (butter_2_10_100.mat). This contains
%      coefficients calculated for 2nd order high pass filter for a sampling 
%      interval of 100Hz, and a cutoff period of 10s. There are two sets
%      of coefficients called a and b, each a [1x3] sized vector.
%
%_______________________________________________________________________
% Refs and Background reading:
% 
% The implementation of this toolbox is described in:
% Hutton et al, 2011, NeuroImage.
% 
% The methods are based on the following:
% Glover et al, 2000, MRM, (44) 162-167 
% Josephs et al, 1997, ISMRM, p1682
% Birn et al, 2006, NeuroImage, (31) 1536-1548
%
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2010)
%  Chloe Hutton 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

%--------------------------------------------------------------------------
if ~isempty(allcpulset) && ~isempty(allcpulset) && std(allcpulset)>0
    cpulsefit=fit_cardiac(allcpulset,allscannert);
    cardiac_sess=sample_cardiac(cpulsefit,allslices,nslices,slicenum,ndummies);
    cardiac=cardiac_sess;
    fprintf('Calculating cardiac regressor of length %d...\n',size(cardiac,1));
    
    % Calculate cardiac rate and convert to beats-per-minute
    hr = heart_rate(allcpulset,allscannert);
    hrvol=hr(((ndummies*nslices)+slicenum):nslices:end);
    hrvol=hrvol(1:size(cardiac_sess,1));
    hrvolsess=2*hrvol/(max(hrvol)-min(hrvol));
else
    cardiac=[];
    hrvolsess=[];
end
if ~isempty(allresp) && ~isempty(allresp) && std(allresp)>0
    rpulset=filter_respiratory(allresp,rsampint);
    rpulsefit=fit_respiratory(rpulset,rsampint);
    respire_sess=sample_respiratory(rpulsefit,rsampint,allscannert,allslices,nslices,slicenum,ndummies);
    %%%
    rvt_all=fit_rvt(rpulset,rsampint);
    rvt_sess=sample_rvt(rvt_all,rsampint,allscannert,allslices,slicenum,nslices,ndummies);
    %%%
    respire=respire_sess;
    rvt=rvt_sess;
    fprintf('Calculating respiratory regressor of length %d...\n',size(respire,1));
    
    % Estimate running standard deviation
    rvt = resp_var(rpulset,rsampint,allscannert);
    rv=resp_IRF(rvt,allscannert);
    % Sample to volumes
    rvvol=rv(((ndummies*nslices)+slicenum):nslices:end);
    rvvolsess=2*rvvol/(max(rvvol)-min(rvvol));
else
    respire=[];
    rvvolsess=[];
end
% Make sure everything is same length
minlen=min([size(cardiac,1) size(respire,1)]);
cardiac=cardiac(1:minlen,:);
respire=respire(1:minlen,:);

if ~isempty(hrvolsess) && ~isempty(rvvolsess)   
    hrrv=[hrvolsess(1:minlen,:) rvvolsess(1:minlen,:)];
elseif ~isempty(hrvolsess)
    hrrv=hrvolsess(1:minlen,:);
elseif ~isempty(rvvolsess)
    hrrv=rvvolsess(1:minlen,:);
else
    hrrv=[];
end
cardiacqrs=[];
