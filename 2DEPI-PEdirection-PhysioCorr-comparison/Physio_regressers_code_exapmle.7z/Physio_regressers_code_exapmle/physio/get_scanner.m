function [scansession, slicesession]=get_scanner(allscannert,allslices)
%
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2007)
% Eric Feathersone and Chloe Hutton 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% Check for scanbreaks
% If there is a time gap greater than a normal TR, e.g. 1s
scanbreak=find(diff(allscannert)>1.0);
nsessions=length(scanbreak)+1;

for sessnum=1:nsessions
   if sessnum==1 
      startscan = 1;
   else
      startscan = scanbreak(sessnum-1)+1;
   end
   if sessnum==nsessions 
      stopscan = size(allscannert,1);
   else
      stopscan = scanbreak(sessnum);
   end  

   % Pull out scans of interest
   scansession{sessnum} = allscannert(startscan:stopscan); 
   
   % Correct for slices in case of incorrect slice numbers
   if any( isnan(allslices) )
       slices = (startscan:stopscan)'-startscan+1;
   else
       slices = allslices(startscan:stopscan);
   end
   
   % If any differences are greater than 1...
   if any(diff(slices)>1)
      disp('Calculating slice numbers...');
      X=1:length(slices);
      corrslices=slices;
      n=find(diff(corrslices)>1);
      while size(n,1)>2
         corrslices(n+1)=X(n+1);
         n=find(diff(corrslices)>1);
      end
      % Do robust fit to get slice numbers in case there are deviations from
      % correct slice numbers   
      warning off stats:statrobustfit:IterationLimit
      B=robustfit(X',corrslices);
      Y=round(B(1)+B(2)*X);
      slices=Y';
   end
   slicesession{sessnum}=slices;
end
