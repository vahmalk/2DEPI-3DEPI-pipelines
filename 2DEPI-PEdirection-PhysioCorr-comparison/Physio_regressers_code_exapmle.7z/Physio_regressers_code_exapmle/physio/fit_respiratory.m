function respire = fit_respiratory(pulset,rsampint)
% fit_respiratory is a function for creating respiratory phase regressor.
% from physiological monitoring files acquired using spike, that
% can be included in SPM5 design matrices.
%
% FORMAT [respire]=fit_respiratory(pulset,rsampint)
%
% Inputs: 
%        pulset - respiratory belt data read from spike file
%        rsampint - sampling frequency
%
% Outputs:
%        respire - respiratory regressor calculated from respiratory phase.
%        This is a 6 x N array (N scans) containing the 1st, 2nd and 3rd order 
%        fourier series (3 sines and 3 cosines) modelling the measured respiratory phase.
% 
% The regressors are calculated in the following way as described in
% Glover et al, 2000, MRM, (44) 162-167: 
% 1) Find the max and min amplitudes from belt response
% 2) Normalise the respiratory amplitude
% 3) Calculate the histogram from the number of occurences of specific respiratory
%    amplitudes in bins 1:100.
% 4) Calculate the running integral of the histogram for the bin
%    corresponding to each respiratory amplitude
%_______________________________________________________________________
% fit_respiratory.m                         Chloe Hutton 01/10/07 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% Add 2*mean of the pulse to ensure its all positive values
pulset = pulset + 2*(abs(mean(pulset)));
maxr=max(pulset);
minr=min(pulset);
normpulse=maxr*(pulset-minr)/(maxr-minr);
nbins=100;
binsize=maxr/nbins;
h=zeros(nbins,1);

% This takes into account that the pulse may be negative, but actually
% that should have been fixed above
if binsize > 0
   for b=1:nbins
      n=find(normpulse>((b-1)*binsize) & normpulse<=(b*binsize));
      h(b)=length(n);
   end
else
   for b=1:nbins
      n=find(normpulse<((b-1)*binsize) & normpulse>=(b*binsize));
      h(b)=length(n);
   end  
end
n=find(normpulse==0);
h(1)=h(1)+length(n);

% Calculate derivative of normalised pulse wrt time
% over 1 sec of data as described in glover et al.
ksize=round(0.5*(1/rsampint));
kernel=[ones(1,ksize)*-1 0 ones(1,ksize)];
dnormpulse=conv(normpulse,kernel);
dnormpulse=dnormpulse(ksize+1:end-ksize);
n=find(abs(dnormpulse)==0);
if ~isempty(n)
    dnormpulse(n)=1;
end
dnormpulse=dnormpulse./abs(dnormpulse);

for t=1:length(normpulse)    
    binnum=100*(normpulse(t)/maxr);
    rphase(t)=pi*(sum(h(1:round(binnum)))/sum(h)).*dnormpulse(t);
end

% Calculate sines and cosines
c1=cos(rphase)';
s1=sin(rphase)';
c2=cos(2*rphase)';
s2=sin(2*rphase)';
c3=cos(3*rphase)';
s3=sin(3*rphase)';

% Put them all together
respire=[c1 s1 c2 s2 c3 s3]; 
