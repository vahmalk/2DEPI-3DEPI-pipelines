function acq_slicenum=get_slicenum(slicenum,nslices,sliceorder)
% Convert a slice number located in a NIFTI EPI volume to the slice 
% number as it was acquired in time.
%
% FORMAT acq_slicenum=get_slicenum(slicenum,nslices,sliceorder)
%
% Inputs:
%   slicenum - slice number from z voxel coordinate in NIFTI image
%   nslices - number of slices in the volume
%   sliceorder - order of slice acquisition, 'descending', 'ascending',
%   'interleaved'
%   (see
%   http://cast.fil.ion.ucl.ac.uk/pmwiki/pmwiki.php/Main/OrderOfSliceAcquisitonInEPI)
% 
% Outputs:
%   acq_slicenum - slice number converted to acquired slice number
%
% After images from the Siemens scanner have been converted to NIFTI
% format, the slice number (in terms of voxel coordinates) is 1 for the 
% most superior slice (top of head) and increases up to number of slices 
% towards the most inferior slice (bottom of head).
% However, the order in which the images were actually acquired may be 
% 'descending', 'ascending' or 'interleaved'. 
% For the descending case, the slice acquistion order corresponds with 
% the slice number in voxel space. 
% For the ascending case, the slices were acquired in the opposite order 
% to how they are stored in the NIFTI file. Therefore the correction is:
% acq_slicenum_corr=(nslices-slicenum)+1;
% In the interleaved case, for an even number of slices, the slices are 
% acquired in the order [2:2:nslices 1:2:nslices-1]. For an odd nummber 
% of slices they are acquired in the order [1:2:nslices 2:2:nslices-1].
% For both even and odd numbers of slices, the slices are acquired from
% inferior to superior.
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2008)
% Chloe Hutton
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $



switch sliceorder
case {'descending'}                     % Superior to inferior
	acq_slicenum=(nslices-slicenum)+1;
case {'ascending'}                      % Inferior to superior
	acq_slicenum=slicenum;
case{'interleaved'}
    asc_slicenum=(nslices-slicenum)+1;  % Interleaved slices are ascending
    if rem(nslices,2)==0                % Even number of slices and inferior to superior
        slicetimes=[2:2:nslices 1:2:nslices-1];
    elseif rem(nslices,2)==1            % Odd number of slices and inferior to superior
        slicetimes=[1:2:nslices 2:2:nslices-1];
    end
    acq_slicenum=find(slicetimes==asc_slicenum);
end
