function check_physio_data(nsessions,allscannert,allslices,allcpulset,allrpulset,rsampint)
% check_physio_data prints out number of sessions, scanner pulses,
% cardiac and respiratory signals measured.
%
% FORMAT check_physio_data(nsessions,allscannert,allslices,allcpulset,
% allrpulset,rsampint); 
%_______________________________________________________________________
% check_physio_data.m                              Chloe Hutton 02/06/08
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% For each session, print out number of sessions, scanner pulses,
% cardiac and respiratory signals measured.

% Check that the number of sessions in the data is the same as specified by
% the user
sesscount=size(allscannert,2);
if sesscount~=nsessions
   error('Sorry. It looks like there is/are %d session(s)',sesscount);
end

for sessnum=1:nsessions
   numscanpulse=length(allscannert{sessnum});
   numslices=(allslices{sessnum}(end)-allslices{sessnum}(1)+1);
   % Check for time of cardiac pulse recordings
   if ~isempty(allcpulset)
      if ~isempty(allcpulset{sessnum})
         cardiacsesstime=(allcpulset{sessnum}(end)-allcpulset{sessnum}(1));
      else
         cardiacsesstime=0;
      end
   else
       cardiacsesstime=0;
   end
   % Check for time of respiratory pulse recordings
   if ~isempty(allrpulset)
      if ~isempty(allrpulset{sessnum})
         respiresesstime=length(allrpulset{sessnum})*rsampint;
      else
          respiresesstime=0;
      end
   else
      respiresesstime=0;
   end
   fprintf('Session %d:Number of scanner pulses=%d, slices=%d, first slice=%d.\nAcquisition time for cardiac=%fs and respiration=%fs.\n',sessnum,numscanpulse,numslices,allslices{sessnum}(1),cardiacsesstime,respiresesstime);
end
