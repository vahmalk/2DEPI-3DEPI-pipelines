function cardiac = fit_cardiac(pulset,scannert)
% fit_cardiac is a function for creating cardiac phase regressor.
% from physiological monitoring files acquired using spike, that
% can be included in SPM5 design matrices.
%
% FORMAT cardiac=make_cardiac(pulset,scannert)
%
% Inputs: 
%        pulset - respiratory belt data read from spike file
%        scannert - scanner pulses read from spike file
%
% Outputs:
%        cardiac - cardiac regressor calculated from cardiac phase.
%        This is a 6 x N array (N scans) containing the 1st, 2nd and 3rd order 
%        fourier series (3 sines and 3 cosines) modelling the measured cardiac 
%        phase.
% 
% The regressors are calculated as described in
% Glover et al, 2000, MRM, (44) 162-167
% Josephs et al, 1997, ISMRM, p1682
%_______________________________________________________________________
% fit_cardiac.m                       Eric Featherstone and Chloe Hutton 26/03/07 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% Find the time of pulses just before and just after each scanner time
% point. Where points are missing, fill with NaNs and set to zero later.
for i=1:length(scannert)
   n = find(pulset < scannert(i) );
   if ~isempty(n) && (n(end)+1)<=size(pulset,1)
      scannertpriorpulse(i) = pulset(n(end));
      scannertafterpulse(i) = pulset(n(end)+1);
   else
      scannert(i)=NaN;
      scannertafterpulse(i) = NaN;
      scannertpriorpulse(i)= 0;
   end
end 

% Calculate cardiac phase at each slice (from Glover et al, 2000).
cardiac_phase=(2*pi*(scannert'-scannertpriorpulse)./(scannertafterpulse-scannertpriorpulse))';
%cardiac_phase=cardiac_phase((nslices*ndummies)+slicenum:nslices:end);
n=find(isnan(cardiac_phase));
if ~isempty(n)
    warning('Zero-padding for non-existent pulse data in %d slices',size(n,1));
end

c=zeros(size(cardiac_phase,1),5);
s=zeros(size(c));
for i=1:5
   c(:,i)=cos(i*cardiac_phase);
   s(:,i)=sin(i*cardiac_phase);
end
n=find(isnan(c));
c(n)=0;
n=find(isnan(s));
s(n)=0;

% Put them all together 
cardiac=[c(:,1) s(:,1) c(:,2) s(:,2) c(:,3) s(:,3) c(:,4) s(:,4) c(:,5) s(:,5)]; 
