function [varargout] = read_spike_channel(fname,chname)

% read_spike_channel is a function which reads data from a
% specified channel in an exported spike text files. 
% 
% FORMAT data=get_cardiac(fname,chname);
%     
% fname = file string specifying name of exported spike text file.
% chname = name of channel (eg TTL, beat-beat, QRS).
% data = vector containing read data.
%
% The functions ends with an error if the text file can't be found, or
% if the channel anme can't be found or if there is no data.
%
%_______________________________________________________________________
% v1.0 read_spike_channel.m                        Chloe Hutton 25/08/05 
% v1.1 adds Spike CED smr format                            E.F.12/06/06
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $
%
% N.B. Requires Dr Malcolm Lidierth's SON Library
% http://www.kcl.ac.uk/depsta/biomedical/cfnr/lidierth.html

% Add path to SON library:
spikelibdir = fullfile(fileparts(which(mfilename)),'son');
addpath(spikelibdir);

% Read in spike CED text export format

if nargout < 1 || 2 < nargout
    error('Sorry, this function returns 1 or 2 parameters only.')
end

fid=fopen(fname);
if fid==-1
    fclose(fid);
    error('Sorry I can not find the file: %s',fname);
end

if length(fname) == strfind(fname,'.smr')+3
    if ~isnumeric(chname)
        chname = str2double(chname);
        if isempty(chname)
            fclose(fid);
            error('Sorry, invalid channel number.')
        end
    end
    try
       lasterr('');
       [data,header] = SONGetChannel(fid,chname); % NB chname must be a channel number!
    catch
        if ~isempty(lasterr)
            data=[];
            header=[];
        end
    end
elseif length(fname) == strfind(fname,'.txt')+3

    if ~ischar(chname)
        fclose(fid);
        error(['Channel name: ' num2str(chname) ', must be a string.'])    
    end
    
    if nargout == 2
        error('Sorry, header output not supported from txt files.')
    end
    
    % First skip past the first time the word CHANNEL appears
    while 1
        line = fgetl(fid);
        if(line==-1)
            fclose(fid);
            error('Cannot find channel data: %s');
        end
        % Break, when word CHANNEL is found...
        if(~isempty(findstr(lower(line),'channel')))
            break      
        end
    end
    
    endoffile=0;
    nochannel=0;
    
    % Now look for chname
    while 1 
        line = fgetl(fid);
        if(line==-1)
            fclose(fid);
            error('Cannot find channel called: %s',chname);
        end
        % Break, when chname is found...
        if(~isempty(findstr(lower(line),lower(chname))))
            break
        end
    end
    
    % Now skip through other lines before the data
    while 1 
        line = fgetl(fid);
        % If find the word channel before finding data, then there was 
        % no data for that channel
        if(~isempty(findstr(lower(line),'channel')))
            fclose(fid);
            error('Cannot find any data for channel: %s',chname);
        end
        % If find a line which isn't empty and has no " then must be data...
        if(~(isempty(line)))
            if(line(1)~='"')
                break
            end
        end
    end
    
    data=[];
    
    while(~isempty(line) && line(1)~='"')
        data=[data;sscanf(line,'%f')];
        line=fgetl(fid);
    end
    
else
    fclose(fid);
    error('File format not ".txt" or ".smr"');
end % if, elseif...

fclose(fid);

varargout(1) = {double(data)};
if nargout == 2
    varargout(2) = {header};
end
