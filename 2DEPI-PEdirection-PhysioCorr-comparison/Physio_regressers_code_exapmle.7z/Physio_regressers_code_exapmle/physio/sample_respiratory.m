function respire_regressor = sample_respiratory(respire,rsampint,scannert,slices,nslices,slicenum,ndummies)
% sample_respiratory downsamples respiratory phase to one value per volume
%
% FORMAT respiratory_regressor=sample_respiratory(respire,rsampint,scannert,slices,
% nslices,slicenum,ndummies) 
%        
%_______________________________________________________________________
% sample_respiratory                               Chloe Hutton 01/10/07 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

nscans=floor(slices(end)/nslices);
regressor_length=max([nscans-ndummies,0]);
respire_regressor=zeros(regressor_length,6);

% 1) Calculate the time for each respiratory measurement
tmp=scannert(1)+(0:rsampint:length(respire)*rsampint)'; % Get time for sampling

% 3) Calculate when slice of interest is acquired:
first_slice=(nslices*ndummies)+slicenum;
% May start measuring late and in the middle of a scan:
first_slice_to_use=max([(first_slice-slices(1))+1,slices(1)-((nslices*floor(slices(1)/nslices))+slicenum)]);
last_slice=(nscans*nslices);
last_slice_to_use=min([last_slice,size(scannert,1)]);
slicet=scannert(first_slice_to_use:nslices:last_slice_to_use);
respire_tmp=[];

% Put if here in case very short run
if ~isempty(slicet)   
   % Resample regressors at correct times.
   for t=1:length(slicet)
      n=find(abs(tmp-slicet(t))<rsampint);
      respire_tmp(t,1)=respire(n(1),1);
      respire_tmp(t,2)=respire(n(1),2);
      respire_tmp(t,3)=respire(n(1),3);
      respire_tmp(t,4)=respire(n(1),4);
      respire_tmp(t,5)=respire(n(1),5);
      respire_tmp(t,6)=respire(n(1),6);
   end   
   % Fill in volume regressor
   first_vol=1+floor(slices(1)/nslices);
   first_vol_to_use=max((first_vol-ndummies),1);
   respire_regressor(first_vol_to_use:end,:)=respire_tmp;
end
