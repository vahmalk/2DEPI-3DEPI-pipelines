function cardiac_regressor = sample_cardiac(cpulsefit,slices,nslices,slicenum,ndummies)
% sample_cardiac downsamples cardiac phase to one value per volume
%
% FORMAT cardiac_regressor=sample_cardiac(cpulsefit,slices,
% nslices,slicenum,ndummies);
%         
%_______________________________________________________________________
% sample_cardiac.m                                 Chloe Hutton 02/06/08 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

nscans=floor(slices(end)/nslices);
regressor_length=max([nscans-ndummies,0]);
cardiac_regressor=zeros(regressor_length,10);

% This is the tricky bit
first_slice=(nslices*ndummies)+slicenum;
% May start measuring late and in the middle of a scan:
first_slice_to_use=max([(first_slice-slices(1))+1,slices(1)-((nslices*floor(slices(1)/nslices))+slicenum)]);
last_slice=(nscans*nslices);
last_slice_to_use=min([last_slice,size(cpulsefit,1)]);

% Sub-sample the signal
cardiac_tmp=cpulsefit(first_slice_to_use:nslices:last_slice_to_use,:);

% Fill in volume regressor
first_vol=1+floor(slices(1)/nslices);
first_vol_to_use=max((first_vol-ndummies),1);
cardiac_regressor((first_vol_to_use:end),:)=cardiac_tmp;
