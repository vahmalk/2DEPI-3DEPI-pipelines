function rvt_regressor=sample_rvt(rvt_all,rsampint,scannert,slices,slicenum,nslices,ndummies)
% sample_rvt downsamples rvt to one value per volume
%
% FORMAT rvt_regressor=sample_rvt(rvt_all,rsampint,scannert,slices,slicenum,
% nslices,ndummies);         
%_______________________________________________________________________
% sample_rvt.m                                 Chloe Hutton 02/06/08 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% 1) Prepare rvt_regressor
nscans=floor(slices(end)/nslices);
regressor_length=max([nscans-ndummies,0]);
rvt_regressor=zeros(regressor_length,1);

peak_index=find(rvt_all~=0);
npeaks=length(peak_index);

% 2) Create vector of timestamps
pulsetimes=scannert(1)+(0:rsampint:length(rvt_all)*rsampint)'; 

% 3) Calculate when slice of interest is acquired:
first_slice=(nslices*ndummies)+slicenum;
% May start measuring late and in the middle of a scan:
first_slice_to_use=max([(first_slice-slices(1))+1,slices(1)-((nslices*floor(slices(1)/nslices))+slicenum)]);
last_slice=(nscans*nslices);
last_slice_to_use=min([last_slice,size(scannert,1)]);
slicet=scannert(first_slice_to_use:nslices:last_slice_to_use);

% 4) At every slice, get the rvt point before and the one after and
% interpolate
if ~isempty(slicet) 
   for n=1:length(slicet)
      slice_index=find(pulsetimes<slicet(n));
      if ~isempty(slice_index)
         rvt_index=find(peak_index<=slice_index(end));
         if ~isempty(rvt_index)
            rvtbefore=rvt_all(peak_index(rvt_index(end)));
            timebefore=pulsetimes(peak_index(rvt_index(end)));
            if (rvt_index+1)<npeaks
               rvtafter=rvt_all(peak_index(rvt_index(end)+1));
               timeafter=pulsetimes(peak_index(rvt_index(end)+1));            
               rvt(n,1)=rvtbefore+((rvtafter-rvtbefore)*(slicet(n)-timebefore)/(timeafter-timebefore));
            else
               rvt(n,1)=rvt_all(peak_index(rvt_index(end)));
            end
         else
          rvt(n,1)=0;  
         end
      else
          rvt(n,1)=0;
      end
   end
   % Do mean corection and scale to max-min
   rvtdiff=max(rvt)-min(rvt);
   if rvtdiff~=0
      rvt=(rvt-mean(rvt))/(max(rvt)-min(rvt));
   end
   
   % Fill in volume regressor
   first_vol=1+floor(slices(1)/nslices);
   first_vol_to_use=max((first_vol-ndummies),1);
   rvt_regressor(first_vol_to_use:end,:)=rvt;
end
