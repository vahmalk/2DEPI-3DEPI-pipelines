function [cardiac,cardiacqrs,respire,hrrv]=make_physio_regressors(physiofile,nslices,ndummies,TR,slicenum,nsessions,scanner_channel,...
         cardiacTTL_channel,cardiacQRS_channel,resp_channel)
% make_physio_regressors is a function for creating regressors 
% from physiological monitoring files acquired using spike. The resulting
% regressors can be included in SPM design matrices. 
% This routine converts the spike data into a more generic format which can
% be processed by the routine physio_regressors.m 
%
% FORMAT [cardiac,cardiacqrs,respire,rvt]=
%         make_physio_regressors(physiofile,nslices,
%         ndummies,TR,slicenum,nsessions,scanner_channel,cardiacTTL_channel,cardiacQRS_channel,resp_channel)
%
% See physio_readme.txt and references below for a more complete
% description of inputs, outputs and methods
%
% Inputs: 
%        physiofile - full name and path of spike .smr file
%        nslices - number of slices in the volume
%        ndummies - number of dummy scans 
%        TR - slice TR in seconds
%        slicenum - number of slice to which regressors will
%                   be interpolated
%        nsessions - number of scanning sessions recorded in the file
%        scanner_channel - spike channel number for scanner pulses
%        cardiacTTL_channel - spike channel number for cardiac TTL pulses
%        cardiacQRS_channel - spike channel number for cardiac QRS pulses
%        resp_channel - spike channel number for respiratory belt data
% 
% Outputs:
%        cardiac - cardiac phase regressors. This is a 1 x nsessions cell 
%                  array where each cell contains regressors of (N scans x 10) 
%                  calculated from the TTL pulse.
%        cardiacqrs - currently disabled.
%        respire - respiratory phase regressors. This is a 1 x nsessions cell 
%                  array where each cell contains regressors 
%                  of (N scans x 6) calculated from the respiratory belt.
%        rvt - respiratory volume per unit time and heart rate. This is a 1 x nsessions cell 
%              array where each cell contains regressors of (N scans x 2).
%
% NB:  The routine filter_respiratory, called by this function, tries to use the 
%      matlab function butter from the Matlab Signal Processing toolbox. 
%      If it can't find it, it will ask the use
%      to select a matfile containing the coefficients. A default matfile
%      is distributed with the code (butter_2_10_100.mat). This contains
%      coefficients calculated for 2nd order high pass filter for a sampling 
%      interval of 100Hz, and a cutoff period of 10s. There are two sets
%      of coefficients called a and b, each a [1x3] sized vector.
%
%_______________________________________________________________________
% Refs and Background reading:
% 
% The implementation of this toolbox is described in:
% Hutton et al, 2011, NeuroImage.
% 
% The methods are based on the following:
% Glover et al, 2000, MRM, (44) 162-167 
% Josephs et al, 1997, ISMRM, p1682
% Birn et al, 2006, NeuroImage, (31) 1536-1548
%
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2007)
%  Chloe Hutton 
% $Rev: 400 $ $Date: 2024-01-16 16:21:15 +0000 (Tue, 16 Jan 2024) $


%--------------------------------------------------------------------------
% Check physiofile exists
if 0==exist(physiofile, 'file')
    error('Can not find or open file %s\n',physiofile);
end
fid = fopen(physiofile);

% Read all the physio data, put it into cell array and print out what has
% been measured.
[scannert,slices,cpulset,rpulset,rsampint]=physio_readfile(physiofile,scanner_channel,...
         cardiacTTL_channel,cardiacQRS_channel,resp_channel);     
[allscannert, allslices]=get_scanner(scannert,slices);
if ~isempty(cpulset)
   allcpulset=get_cardiac(allscannert,cpulset);
else
    allcpulset=[];
end
if ~isempty(rpulset)
   allrpulset=get_respiratory(allscannert,rpulset,rsampint);
else
   allrpulset=[];
end

% Print out what has been measured
check_physio_data(nsessions,allscannert,allslices,allcpulset,allrpulset,rsampint);
 
%--------------------------------------------------------------------------
% Now do the processing for each session with user specified inputs
for sessnum=1:nsessions
    if isempty(allcpulset)
        allcpulset{sessnum}=[];
    end
    if isempty(allrpulset)
        allrpulset{sessnum}=[];
    end
   [cardiac{sessnum},cardiacqrs{sessnum},respire{sessnum},hrrv{sessnum}]=physio_regressors(allscannert{sessnum},allslices{sessnum},allcpulset{sessnum},allrpulset{sessnum},rsampint,nslices,ndummies,slicenum);
end
