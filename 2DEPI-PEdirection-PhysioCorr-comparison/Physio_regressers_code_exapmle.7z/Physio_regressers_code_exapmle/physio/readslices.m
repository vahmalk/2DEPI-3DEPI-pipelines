function [slice, slicet] = readslices( t_edge )
% Reads scanner all slice numbers from a set of TTL edge transition timestamps
%
% [slice slicet] = readslices( t_edge )
%________________________________________________________
% readslices.m
% $Rev: 403 $ $Date: 2024-01-24 15:04:06 +0000 (Wed, 24 Jan 2024) $

global nslices

% some magic numbers; bounds on lengths of Siemens, serial, and Vol3ms etc triggers
seriallower  = 13e-6;   % 13us is larger than Siemens 10us vol triggers but smaller than 57600 baud serial bit length
serialupper = 1000e-6;   % 1ms is larger than 9600 baud serial bit length but smaller than Vol3ms or Slice3ms triggers
%   10 us between edges for Siemens volume triggers
%   17 us between edges @ 57600 baud (17.36111 us)
%   70 us between edges @ 14400 baud (69.44444 us)
%  104 us between edges @  9600 baud (104.1666 us)
% 3000 us between edges for Vol3ms & Slice3ms triggers
gap = 7e-3;             % 3ms < gap < 10ms : see below
% 2ms for 20 bits @ 10000 bps,
% 2.777ms for 40 bits @ 14400 bps
% 3ms for 'Vol3ms' & 'Slice3ms'
% 10ms is shortest inter-packet gap; between 'V' & 'N' packets
slicevolthreshold = 0.2;% 0.2s bound between slice TR and vol TR

diffs = diff(t_edge);
diffs = diffs( diffs<gap );                             % not interested in gaps btwn slices

%% Are these Cogent triggers,
% or Siemens volume, Vol3ms, or Slice3ms triggers?
if seriallower < max(diffs) && min(diffs) < serialupper % betwenn these limits implies serial data
    disp('I think these are "Cogent" triggers. Analysing baudrate...')
    
    %% Automatic bit rate detection
    baudlist  = [ 9600 10000 14400 19200 38400 57600];  % edit to suit though note that the Spike default 5us time resolution will not be sufficient to discriminate between baud rates > 57600
    baudlist  = sort(baudlist);                         % this list *must* be sorted
    iy = find( max(diffs) > 8.75./baudlist );           % 8.75 bits found by trial and error.
    if isempty(iy)
        error('Baud rate not found!')
    else
        baud = baudlist(iy(1));
    end
    switch baud
        case {9600,10000}
            nbits = 20; nbytes = 2;     % legacy 2 byte packets
            disp(['I think this is ' num2str(baud) ' bits per second & legacy 2 byte data packets.'])
        otherwise
            nbits = 40; nbytes = 4;     % PRISMA 4 byte packets
            disp(['I think this is ' num2str(baud) ' bits per second & PRISMA 4 byte data packets.'])
    end
    
    %% Find packets
    ix     = find( diff(t_edge)>gap );
    pstart = [1; ix+1];
    pend   = [ix; length(t_edge)];
    if t_edge(1) < (9/baud) % might need to discard a partial "first" slice!
        pstart(1) = [];
        pend(1)   = [];
    end
    npackets = length(pstart);
    
    %% Decode bytes
    bitpattern = repmat('0', npackets,nbits); % pre-allocate result array. More than 20x faster than dec2bin(zeros(length(starts),1),nbits),nbits)
    for n=1:npackets
        bitcounts = [ round(baud*(t_edge(pstart(n):pend(n))-t_edge(pstart(n)))); nbits];
        if all(bitcounts>=0)
            for m=2:2:length(bitcounts)-1
                bitpattern( n,(1+bitcounts(m)):bitcounts(m+1) ) = '1';
            end
        else
            warning('Bad bit time!')
        end % if all(bitcounts>=0)
    end % for n
    
    %% Decode packets
    databits = 9:-1:2;                                      % bit ordering  : little-endian
    byte = []; for n=0:10:30; byte=[byte; n+databits]; end  % byte ordering : big-endian
    switch baud
        case {9600,10000}                                   % legacy 2 byte packets
            slice  = bin2dec( bitpattern(:,[byte(1,:) byte(2,:)]) );
            slicet = t_edge( pstart );
        otherwise                                           % PRISMA 4 byte packets
            code   = bin2dec( bitpattern(:, byte(1,:) ) );
            slice  = bin2dec( bitpattern(:,[byte(2,:) byte(3,:) byte(4,:)]) );
            slicet = t_edge( pstart );
            ix     = find(code=='S');
            slice  = slice(ix);
            slicet = slicet(ix);
    end
    
else %% Vol3ms, Slice3ms 3ms triggers, or Siemens volume 10us triggers
    trig_t = t_edge(1:2:end);                   % remove falling edges
    if min(diff(trig_t)) < slicevolthreshold    % implies slice triggers
        disp('I think these are "Slice3ms" triggers.')
        slice  = (1:length(trig_t))';           % regenerate slice numbers assume starting from 1
        slicet = trig_t;
    else
        if max(diffs) <= seriallower            % implies 10us Siemens volume triggers
            disp('I think these are Siemens 10us volume triggers.')
        elseif serialupper <= min(diffs)        % implies FIL 3ms volume or slice triggers
            disp('I think these are "Vol3ms" volume triggers.')
        else                                    % all bases should be covered so should never get here!
            error('Should never get here! - some problem discriminating volume or slice triggers.')
        end
        
        VolumeTR = (trig_t(11)-trig_t(1))/10;   % average over first 10 volumes
        SliceTR  = VolumeTR/nslices;            % calculate based on slices per vol
        nvols    = length(trig_t);              % number of volumes = number of triggers
        numslices  = nvols*nslices;             % number of slices = number of volumes * slicespervol
        
        slicet = interp1( 1:nslices:numslices, trig_t, 1:numslices );
        slicet( ((nvols*nslices)-nslices+2):end ) = slicet( numslices-nslices+1 ) + (1:nslices-1)*SliceTR; % triggers for the slice s of the last volume
        slicet = slicet';
        slice  = (1:length(slicet))';           % regenerate slice numbers assume starting from 1
    end
end