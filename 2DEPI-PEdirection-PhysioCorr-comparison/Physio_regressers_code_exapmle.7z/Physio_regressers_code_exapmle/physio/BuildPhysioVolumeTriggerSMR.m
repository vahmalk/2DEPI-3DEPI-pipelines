%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    BuildPhysioVolumeTriggerSMR regressors for physio files with only one
%    trigger per volume
%    NC 11.04.18
%    PhysioFile:   Physio file (smr format)
%    TotalNbSlice: Total nb of slices acquired per volume
%    ndummies:     Number of dummy scans to discard at the beginning
%    slicenum:     Reference slice number
%
%   The matrix of regressors will be written into the folder of the smr 
%   file, with the suffix _R
% 
%  Example:  R=BuildPhysioVolumeTriggerSMR('007run1.smr',48,0,24)
%
%  $Rev: 401 $ $Date: 2024-01-23 17:52:05 +0000 (Tue, 23 Jan 2024) $
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [R]=BuildPhysioVolumeTriggerSMR (PhysioFileName,TotalNbSlices,ndummies,slicenum)

%% Port numbers 
%%% Default values currently in place at the FIL (should be changed if another setup is used)
scanner_channel   = 1;
cardiacTTL_channel= 2;
resp_channel      = 4;
cardiacQRS_channel= 5;

check_channels(PhysioFileName,scanner_channel,cardiacTTL_channel,cardiacQRS_channel,resp_channel);

%% Scanner triggers
[allscannert, hdr{scanner_channel}]=read_spike_channel(PhysioFileName,scanner_channel);

%% Artificals triggers are added between real triggers
%%%  to simulate slices.

Trig_times=allscannert;
Trig_times_pos=Trig_times(1:2:end); % Only Positive trig
VolumeTR=(Trig_times_pos(11)-Trig_times_pos(1))/10;
SliceTR=VolumeTR/TotalNbSlices;

allscannert=(interp1(1:TotalNbSlices:TotalNbSlices*length(Trig_times_pos),Trig_times_pos,1:1:TotalNbSlices*length(Trig_times_pos)));
allscannert((length(Trig_times_pos)*TotalNbSlices)-TotalNbSlices+2:end)= allscannert((length(Trig_times_pos)*TotalNbSlices-TotalNbSlices+1))+SliceTR*(1:TotalNbSlices-1);%% triggers for the slice s of the last volume
allscannert=allscannert';

%% Cardiac traces
[allcpulset, hdr{cardiacTTL_channel}]=read_spike_channel(PhysioFileName,cardiacTTL_channel);
 cpulset=get_cardiac(allscannert,allcpulset);
%% Respiratory Traces
[allrpulset, hdr{resp_channel}]=read_spike_channel(PhysioFileName,resp_channel);
allrpulset=allrpulset';
rsampint = hdr{resp_channel}.sampleinterval;
rpulset=get_respiratory(allscannert,allrpulset,rsampint);
%% Build regressors 
allslices=1:length(allscannert);
[cardiac,cardiacqrs,respire,hrrv]=physio_regressors(allscannert,allslices,cpulset{1},rpulset{1},rsampint,TotalNbSlices,ndummies,slicenum);
 
%% Save matrix of physio regresors 
R=[cardiac(:,1:6) respire hrrv];
R=R-repmat(mean(R),size(R,1),1);

[pn, fn]=fileparts(PhysioFileName);
save(fullfile(pn,strcat(fn,'_R_session1.mat')),'R')