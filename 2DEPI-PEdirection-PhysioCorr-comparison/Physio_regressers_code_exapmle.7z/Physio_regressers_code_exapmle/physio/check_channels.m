function check_channels(physiofile,scanner_channel,cardiacTTL_channel,cardiacQRS_channel,resp_channel)
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2008)
% Chloe Hutton
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

if 0==exist(physiofile, 'file')
    error('Can not find or open file %s\n',physiofile);
end
fid = fopen(physiofile);
channels = SONChanList(fid);
chnum=cat(1,channels(:).number);
if ~isempty(scanner_channel)
   n=find(scanner_channel==chnum);
   if ~isempty(n)
      fprintf('I think scanner is called %s\n',channels(n(1)).title);
   end
end
if ~isempty(cardiacTTL_channel)
   n=find(cardiacTTL_channel==chnum);
   if ~isempty(n)
      fprintf('I think TTL is called %s\n',channels(n(1)).title);
   end
end
if ~isempty(cardiacQRS_channel)
   n=find(cardiacQRS_channel==chnum);
   if ~isempty(n)
      fprintf('I think cardiac qrs is called %s\n',channels(n(1)).title);
   end
end
if ~isempty(resp_channel)
   n=find(resp_channel==chnum);
   if ~isempty(n)
      fprintf('I think respiratory is called %s\n',channels(n(1)).title);
   end
end
