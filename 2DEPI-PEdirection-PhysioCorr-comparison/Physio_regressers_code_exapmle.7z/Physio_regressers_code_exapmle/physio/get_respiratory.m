function rpulset=get_respiratory(allscannert,allrpulset,rsampint)
%_______________________________________________________________________
% get_respiratory.m     Eric Feathersone and Chloe Hutton 01/10/07 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% Get scanner sessions
if iscell(allscannert)
   nsessions=size(allscannert,2);
else
   nsessions=1;
   tmp=allscannert;
   clear allscannert;
   allscannert{1}=tmp;
end
  
% Check that something is measured
if std(allrpulset)>0
   for sessnum=1:nsessions 
      scannert=allscannert{sessnum};    
      % First work out start and stop for session
      %startr = max(1,floor(scannert(1)/rsampint)-1);       
      %stopr = ceil(scannert(end)/rsampint)+1;
      startr = max(1,floor(scannert(1)/rsampint));       
      stopr = ceil(scannert(end)/rsampint);
      rpulset{sessnum} = allrpulset(min(startr,end):min(stopr,end));
   end
else
   for sessnum=1:nsessions 
      rpulset{sessnum}=[];
   end
   warning('No respiratory data was recorded for any sessions');
end
