function rpulset=filter_respiratory(rpulset,rsampint)
% filter_respiratory is a function for high-pass filtering respiratory data.
%
% FORMAT rpulset=filter_respiratory(pulset,rsampint)
%
%_______________________________________________________________________
% filter_respiratory.m                             Chloe Hutton 01/10/07 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% Check that something is measured          
if ~isempty(rpulset) && std(rpulset)>0
   % Correct regressor to zero
   rpulset=rpulset-rpulset(1);

   % Next step is to high-pass filter the pulse over the session
   cutoff=10/rsampint; %10 seconds/rsampint units
   forder=2;
   if exist('butter')==2
      [b,a]=butter(forder,2/cutoff,'high');
   else % Special case for when no signal processing tool box
      wd = fileparts(which(mfilename));
      hpfcoefs=spm_select(1,'^*\.mat$','Select a mat file containing high pass filter coefficients',[],wd);
      load(hpfcoefs);
   end
   rpulset=filter(b,a,rpulset);
         
   % Now do a check for any outliers (> 3std)
   mpulse=mean(rpulset);
   stdpulse=std(rpulset);
   outliers=find(rpulset>(mpulse+(3*stdpulse)));
   pulset(outliers)=mpulse+(3*stdpulse);
   outliers=find(rpulset<(mpulse-(3*stdpulse)));
   rpulset(outliers)=mpulse-(3*stdpulse);
else
   rpulset=[];
end
