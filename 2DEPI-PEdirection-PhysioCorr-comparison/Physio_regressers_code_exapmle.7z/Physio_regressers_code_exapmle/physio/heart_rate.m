function hr = heart_rate(pulset,scannert)
% Estimate heart rate (number of beats per unit time) from
% time stamps of beats and corresponding scanner pulses
% FORMAT hr = physio_heart_rate(pulset,scannert)
%
% pulset - 
% scannert - 
% hr -
%
% Code is based on Chang and Glover 2009.
% ___________________________________________________________________
% Copyright (C) 2010 Wellcome Trust Centre for Neuroimaging
% Chloe Hutton
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% Get a vector of beat-to-beat intervals with mean and std
dpulset=diff(pulset);
meanpulset=mean(dpulset);
stdpulset=std(dpulset);

% Find outlier values where time between beats are outside mean+/-3*std
nout=find(dpulset<(meanpulset-(3*stdpulset)) | dpulset>(meanpulset+3*stdpulset));
% Find OK values where time between beats are within mean+/-3*std
nin=find(dpulset>(meanpulset-(3*stdpulset)) & dpulset<(meanpulset+3*stdpulset));
nmeanpulset=mean(dpulset(nin));
dpulset(nout)=nmeanpulset;

% the beat-to-beat interval tends to be a little noisy 
% so average over 3 beats
dpulset_m1=[dpulset(2:end);dpulset(end)];
dpulset_p1=[dpulset(1);dpulset(1:end-1)];
sdpulset=(dpulset+dpulset_m1+dpulset_p1)/3;

% Get the beat-to-beat interval at each slice TR
totslices=size(scannert,1);
bbint=ones(totslices,1)*mean(sdpulset);
for i=1:length(scannert)
   n = find(pulset < scannert(i) );
   if ~isempty(n) && (n(end))<=(size(pulset,1)-1)
      bbint(i)=sdpulset(n(end));
   end
end 

% If we like 6 seconds then should get the TR passed to the function
% or instead average over samples? THINK ABOUT THIS
% win=round(3*nslices/2);
% Average over 6 second window 
slicetr=mean(diff(scannert));
win=round(6/slicetr);
avbbint=bbint;
for nav=1:totslices
    if nav>win && nav<=size(bbint,1)-win
        start=nav-win+1;
        stop=nav+win;
    elseif nav<=win
        start=1;
        stop=nav+win; 
    elseif nav>size(bbint,1)-win
        start=nav-win+1;
        stop=nav; 
    end
    avbbint(nav)=mean(bbint(start:stop));
end
% Convert to beats-per-min
iavbbint=60./avbbint;
%iavbbint=(60*samplerate./avbbint);
% mean(iavbbint)/60
% std(iavbbint)/60

% Construct IRF from Chang
t=(0:totslices-1)'*slicetr;
hirf=(0.6*(t.^2.7).*exp(-1*t./1.6)) - 16*1/(sqrt(2*pi*9)).*exp(-0.5*((t-12).^2)/9);
hr=conv(iavbbint-mean(iavbbint),hirf);
hr=hr(1:totslices);

% Do the stuff below outside
%hr=2*hr/(max(hr)-min(hr));
% hrvol=hr(((ndummies*nslices)+refslice):nslices:end);
% hrvol=2*hrvol/(max(hrvol)-min(hrvol));
