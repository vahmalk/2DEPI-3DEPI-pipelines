function rv=resp_IRF(pulset,scannert)
% Estimate Impulse Response Function for respiratory rate 
%
% pulset 
% sampint
%
% Code is based on Birn et al 2008 and Chang and Glover 2009
% ___________________________________________________________________
% Copyright (C) 2010 Wellcome Trust Centre for Neuroimaging
% Chloe Hutton
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

pulselength=size(pulset);
slicetr=mean(diff(scannert));
t=(1:pulselength)'*slicetr;
rirf=(0.6.*(t.^2.1).*exp(-t./1.6)) - (0.0023.*(t.^3.54).*exp(-t./4.25));
rv=conv(pulset-mean(pulset),rirf);
rv=rv(1:pulselength);
