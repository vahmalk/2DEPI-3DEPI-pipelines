function rvt=resp_var(pulset,rsampint,scannert)
% Resample respiration at scanner pulses
%
%________________________________________________________
% resp_var.m
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

slicetr=mean(diff(scannert));
counter=1;
newpulset(counter)=pulset(1);
for n=2:size(pulset,1)
    newsamp=round(n*slicetr/rsampint);
    if newsamp>=1 && newsamp<size(pulset,1)
        counter=counter+1;
        newpulset(counter)=pulset(newsamp);
    end
end
newpulset(size(scannert,1))=pulset(end);
newpulset=newpulset';

totslices=size(newpulset,1);
slicetr=mean(diff(scannert));
sampwin=6/slicetr;
opulset=newpulset;

% Do a check for any outliers (> N std)
N=2;
mpulse=mean(newpulset);
stdpulse=std(newpulset);
outliers=find(newpulset>(mpulse+(N*stdpulse)));
newpulset(outliers)=mpulse+(N*stdpulse);
outliers=find(newpulset<(mpulse-(N*stdpulse)));
newpulset(outliers)=mpulse-(N*stdpulse);
rvt=newpulset;

for n=1:totslices   
    start=n-round(sampwin/2);
    stop=n+round(sampwin/2);
    if start<1
       start=1;
    elseif stop > totslices
       stop=totslices;
    end
    rvt(n)=std(newpulset(start:stop));
    %rvt(n)=sqrt(mean(max(pulset(start:stop))-min(pulset(start:stop))).^2);
end
