function rvt = fit_rvt(pulset,rsampint)
% fit_rvt is a function for creating change in respiratory volume 
% per unit time regressor from physiological monitoring files 
% acquired using spike, that can be included in SPM5 design matrices.
%
% FORMAT [rvt]=fit_rvt(pulset,rsampint)
%
% Inputs: 
%        pulset - respiratory belt data read from spike file
%        rsampint - sampling frequency
%
% Outputs:
%        rvt - regressor calculated from respiratory belt data.
%              This is a 1 x N array (N scans).
% 
% The regressors are calculated as described in
%
% Birn et al, 2006, NeuroImage, (31) 1536-1548
%_____________________________________________________________________
% fit_rvt.m                         Chloe Hutton 01/10/07
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% Calculate derivative of pulse wrt time
% using a kernel that includes about 1 sec of data
ksize=round(0.5*(1/rsampint));
kernel=[ones(1,ksize) 0 ones(1,ksize)*-1];
dpulset=conv(pulset,kernel);
dpulset=dpulset(ksize+1:end-ksize);
n=find(abs(dpulset)==0);
if ~isempty(n)
    dpulset(n)=1;
end

% Get rid of really big values by first calculating the std of 
% the amplitude and thresholding at 3stds
height=std(dpulset);  
n=find(dpulset>(3*height));
dpulset(n)=(3*height);
n=find(dpulset<(-3*height));
dpulset(n)=(-3*height);

% Find the downward zero crossings of the derivative to locate the pulse maxima
rrint=((dpulset(2:end)<=0)&(dpulset(1:end-1)>=0));
findmaxpeaks=find(rrint);
maxpeaks=zeros(size(dpulset));
maxpeaks(findmaxpeaks)=1;
finderrors=find(pulset(findmaxpeaks)<0);
maxpeaks(findmaxpeaks(finderrors))=0;

% Find the upward zero crossings of the derivative to locate the pulse minima
rrint=((dpulset(2:end)>=0)&(dpulset(1:end-1)<=0)); 
findminpeaks=find(rrint);
minpeaks=zeros(size(dpulset));
minpeaks(findminpeaks)=1;
finderrors=find(pulset(findminpeaks)>0);
minpeaks(findminpeaks(finderrors))=0;

% Do peak test to ensure only one minima between each maxima 
nmaxpeaks=find(maxpeaks==1);
nminpeaks=find(minpeaks==1);
for np=2:length(nmaxpeaks)
    nbetween=find(nminpeaks<nmaxpeaks(np) & nminpeaks>nmaxpeaks(np-1));
    % If more than one peak between, convert them all to 0 and the 
    % minimum to 1
    if length(nbetween)>1
        [val,indx]=min(pulset(nminpeaks(nbetween)));  
        minpeaks(nminpeaks(nbetween))=0;
        minpeaks(nminpeaks(nbetween(indx)))=1;
    end
end
% Do peak test to ensure only one maxima between each minima 
nmaxpeaks=find(maxpeaks==1);
nminpeaks=find(minpeaks==1);
for np=2:length(nminpeaks)
    nbetween=find(nmaxpeaks<nminpeaks(np) & nmaxpeaks>nminpeaks(np-1));
    % If more than one peak between, convert them all to 0 and the 
    % minimum to 1
    if length(nbetween)>1
        [val,indx]=max(pulset(nmaxpeaks(nbetween)));  
        maxpeaks(nmaxpeaks(nbetween))=0;
        maxpeaks(nmaxpeaks(nbetween(indx)))=1;
    end
end
   
% Now calculate 1) difference between
% adjacent max and min and 2) the respiration period
nmax=find(maxpeaks==1);
nmin=find(minpeaks==1);
npeaks=min([length(nmax) length(nmin)]);
resp_period=zeros(size(pulset));
resp_amp=zeros(size(pulset));
rvt=zeros(size(pulset));
if nmax(1)<nmin(1)
    peak_index=nmax;
else
    peak_index=nmin;
end
resp_period(peak_index(1:npeaks-1))=diff(peak_index(1:npeaks));
resp_amp(peak_index(1:npeaks-1))=pulset(nmax(1:npeaks-1))-pulset(nmin(1:npeaks-1));
rvt(peak_index(1:npeaks-1))=resp_amp(peak_index(1:npeaks-1))./resp_period(peak_index(1:npeaks-1));
