Physiological Noise Correction - May 2011
*****************************************
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2011)
% Chloe Hutton and Eric Featherstone
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

Contents
--------    
    * Reading and references
    * Using physio toolbox with gui
    * Using physio toolbox in a script 
    * Using physio toolbox with more generic physiological data (i.e. not from spike)
   
Reading and references
---------------------------------------------
Please find below a full description of the physio toolbox of which all or part can be used in publications:

During scanning sessions peripheral measurements of subject pulse and breathing were made together with scanner slice synchronisation pulses using Spike2 data acquisition system (Cambridge Electronic Design Limited,Cambridge UK). The cardiac pulse signal was measured using an MRI compatible pulse oximeter (Model 8600 F0, Nonin Medical, Inc. Plymouth, MN) attached to the subject’s finger. The respiratory signal, thoracic movement, was monitored using a pneumatic belt positioned around the abdomen close to the diaphragm.

A physiological noise model was constructed to account for artifacts related to cardiac and respiratory phase and changes in respiratory volume using an in-house developed Matlab toolbox (Hutton et al, 2011). Models for cardiac and respiratory phase and their aliased harmonics were based on RETROICOR (Glover et al., 2000) and a similar, earlier method (Josephs et al., 1997). Basis sets of sine and cosine Fourier series components extending to the 5rd harmonic (i.e. 5 terms) for the cardiac phase and 3rd harmonic for the respiratory phase were used to model the physiological fluctuations. The model for changes in respiratory volume was based on (Birn et al., 2006). This resulted in a total of 17 regressors which were sampled at a reference slice in each image volume to give a set of values for each time point. The resulting regressors were included as confounds in the first level analysis for each subject.

Reference List

   1. Hutton, C., Josephs, O., Stadler, J., Featherstone, E., Reid, A., Speck, O., Bernarding, J., et al. (2011). The impact of physiological noise correction on fMRI at 7T NeuroImage. doi:10.1016/j.neuroimage.2011.04.018
   2. Glover, G.H., Li, T.Q., Ress, D., 2000. Image-based method for retrospective correction of physiological motion effects in fMRI: RETROICOR. Magn Reson.Med 44, 162-167.
   3. Josephs, O., Howseman, A.M., Friston, K., Turner R., 1997. Physiological noise modelling for multi-slice EPI fMRI using SPM. Proceedings of the 5th Annual Meeting of ISMRM, Vancouver, Canada, p. 1682.
   4. Birn, R.M., Diamond, J.B., Smith, M.A., Bandettini, P.A., 2006. Separating respiratory-variation-related fluctuations from neuronal-activity-related fluctuations in fMRI. Neuroimage. 31, 1536-1548. 

*******************************************

Using physio toolbox with gui
-----------------------------

   1. Start the physio toolbox from the SPM toolbox menu...
   2. Enter the number of slices per volume, number of dummy volumes, slice TR (in ms), slice order (see here to check this), number of scan sessions included in the file (where starting and stopping the scanner for an EPI run while spike is recording physio data comprises one session - even if the data wasn't useful) and slice of interest to which regressors should be sampled.
   3. The slice of interest should be one that contains a particular region of interest and is likely to be badly affected by physiological noise. You can identify the 'stored' slice number in the image by displaying one of the original fMRI images using the display button in SPM. The slice number will be the z voxel coordinate (NOT the mm coordinate). NB You must select this slice number from the images before any realignment or normalisation.
   4. Give the name of the spike file which should be in the binary .smr format.
   5. Select the appropriate channel names from the ones extracted from the spike file. Identify the channels of interest for the measured signals otherwise select 'None'.
   6. The physiological regressors are constructed and the results saved in matlab files in the same directory as the spike file.
   7. Each set of regressors from each scanning session are saved as a separate file as follows:
          * cardiac_sess - regressors modelling cardiac phase from pulse oximeter TTL pulse. This is an (N scans x 10) array. The 10 columns contain the 1st to 5th order Fourier series (5 sines and 5 cosines) modelling the measured cardiac phase. The result for each session is saved with the name spikefilename_cardiac_sessionX.mat.
          * cardiacqrs_sess - currently disabled
          * respire_sess - regressors modelling respiratory phase from respiratory belt signal. This is an (Nscans x 6) array. The 6 columns contain the 1st, 2nd and 3rd order Fourier series (3 sines and 3 cosines) modelling the measured respiratory phase. The result for each session is saved with the name spikefilename_respire_sessionX.mat.
          * rvt_sess - regressor modelling the change in respiratory volume per unit time and heart rate. This is a an (Nscans x 2) array. The file is saved with the name spikefilename_rvt_sessionX.mat. 
   8. The different regressors for each session are also saved together in an (Nscans x nregressors) array called R. This is saved with the filename filename_R_sessionN.mat which can be easily loaded under the Multiple Regressors option in SPM to include in a design matrix. By default, R contains 6 cardiac, 6 respiratory, 2 change in respiration and heart rate = 14 regressors (as used in Hutton et al. 2011).
   9. R can also be constructed using R=[cardiac_sess respire_sess rvt_sess];
  10. The physiological regressors can also be combined with realignment parameters into one file e.g. R=[R RP] (where RP are realignment parameters).
  11. A file called 'spikefilename'_physioparams.mat is also saved that contains the parameters used to construct the regressors. 


Using physio toolbox in a script
--------------------------------

   1. The physio toolbox includes a script called physio_script.m which provides an example of how the physio toolbox can be used in a script. 

Using physio toolbox with more generic physiological data (i.e. not from spike)
-------------------------------------------------------------------------------

   1. The physio toolbox includes a script called physio_raw_data_script.m which provides an example of how the physio toolbox can be used to process more generic physiological data and physio_raw_data_example.mat contains example generic data in the required format. 


