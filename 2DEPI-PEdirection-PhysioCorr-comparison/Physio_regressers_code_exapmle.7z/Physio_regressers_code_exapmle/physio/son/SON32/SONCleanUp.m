function SONCleanUp()
% SONCLEANUP File cleanup. Not used in Windows
%
% Author:Malcolm Lidierth
% Matlab SON library:
% Copyright 2005 � King�s College London

calllib('son32','SONCleanUp');
return;
