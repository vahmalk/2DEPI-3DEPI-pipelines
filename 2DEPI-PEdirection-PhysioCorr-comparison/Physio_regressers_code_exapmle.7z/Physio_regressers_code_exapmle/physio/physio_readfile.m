function [allscannert,allslices,allcpulset,allrpulset,rsampint]=physio_readfile(physiofile,scanner_channel,...
         cardiacTTL_channel,cardiacQRS_channel,resp_channel)
% physio_readfile is a function to read data from physiological monitoring
% files acquired using spike 
%
% FORMAT [allscannert,allslices,allcpulset,allrpulset,rsampint]=physio_readfile(physiofile,scanner_channel,...
%         cardiacTTL_channel,cardiacQRS_channel,resp_channel)
%
% Inputs: 
%        physiofile - full name and path of spike .smr file
%        scanner_channel - spike channel number for scanner pulses
%        cardiacTTL_channel - spike channel number for cardiac TTL pulses
%        cardiacQRS_channel - spike channel number for cardiac QRS pulses
%        resp_channel - spike channel number for respiratory belt data
%     
%_______________________________________________________________________
% make_physio_regressors.m     Eric Feathersone and Chloe Hutton 02/06/08 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% Read all the physio data, put it into cell array

% Read scanner pulse channel
lower3mslen = 0.002;    % lower bound on 3ms trig length
upper3mslen = 0.004;    % upper bound on 3ms trig length
lowervollen = 0.2;      % lower bound on vol length; 0.2s?
uppervollen = 6;        % upper bound on vol length; 6s?

if ~isempty(scanner_channel)
   [allscannert, hdr{scanner_channel}]=read_spike_channel(physiofile,scanner_channel);
   if min(diff(allscannert)) < lower3mslen      % then assume "Cogent" triggers
       disp('Using "Cogent" style scanner triggers...')
       [allslices, allscannert] = readslices(allscannert);
   elseif lower3mslen < min(diff(allscannert)) && min(diff(allscannert)) < upper3mslen % then assume 3ms triggers (Slice or Vol)
       ix = find( diff(allscannert) < upper3mslen );
       allscannert(ix+1) = [];                  % remove 3ms pulse trailing edges
       allslices = NaN(size(allscannert));
       if min(diff(allscannert)) < lowervollen  % then assume "Slice3ms"
           disp('Using "Slice3ms" style scanner triggers...')
       elseif lowervollen < min(diff(allscannert)) && min(diff(allscannert)) < uppervollen % then assume "Vol3ms" triggers
           disp('These are "Vol3ms" style scanner triggers...')
           dlgtitle = '"Vol3ms" triggers';
           quest = 'Please use Nadege Corbin''s BuildPhysioVolumeTriggerSMR.m function to analyse "Vol3ms" triggers.';
           defbtn = 'OK';
           questdlg(quest, dlgtitle, defbtn, defbtn);
           error('Please use Nadege Corbin''s BuildPhysioVolumeTriggerSMR.m function on this data.')
       end
   end
else
   error('Sorry. It looks like no scanner pulses were recorded');
end

% Read cardiac TTL pulse channel
if ~isempty(cardiacTTL_channel)
   [allcpulset, hdr{cardiacTTL_channel}]=read_spike_channel(physiofile,cardiacTTL_channel);              
else
   allcpulset=[];
end

% Read respiratory channel
if ~isempty(resp_channel)
    [allrpulset, hdr{resp_channel}]=read_spike_channel(physiofile,resp_channel);
    allrpulset=allrpulset';
    rsampint = hdr{resp_channel}.sampleinterval;
    % If the pulse sampling is less than 0.01Hz, downsample to 0.01
    % Otherwise the datasets are too long for processing.
    if rsampint<0.01
        rsampint=rsampint/0.01;
        allrpulset=allrpulset(1:round(1/rsampint):end);
    end
else
    allrpulset=[];
    rsampint=[];
end
