% bucni_physio_script.m
% Script that calls physio routines to construct physiological regressors
% acquired at BUCNI.
% This script is for demonstration purposes and will need editing in order
% to generate the required regressors.
% The main routine to create the physio regressors is make_bucni_physio_regressors
%
%_______________________________________________________________________
% Refs and Background reading:
%
% The implementation of this toolbox is described in:
% Hutton et al, 2011, NeuroImage.
%
% The methods are based on the following:
% Glover et al, 2000, MRM, (44) 162-167
% Josephs et al, 1997, ISMRM, p1682
% Birn et al, 2006, NeuroImage, (31) 1536-1548
%
%________________________________________________________
% (c) Wellcome Trust Centre for NeuroImaging (2010)

% Chloe Hutton
% $Id: bucni_physio_script.m 287 2011-12-15 17:08:23Z chloe $

% NEED TO EDIT VALUES BELOW
scanner_channel = 1;
cardiac_channel = 2;
resp_channel1=3;
resp_channel2=4;
channels=[scanner_channel cardiac_channel resp_channel1 resp_channel2];
nslices=36;
ndummies=0;
refslice=16;
physiofilename = 'bucni_example.daq';

[cardiac,respire,hrrv]=make_bucni_physio_regressors(physiofilename,nslices,ndummies,refslice,channels);

% May want to use a specific path for saving the output
filename = fullfile(sprintf('%s_R',spm_str_manip(physiofilename,'tr')));
R=[cardiac(:,1:6) respire hrrv];
R=R-repmat(mean(R),size(R,1),1);
save(filename,'R');

% % You may also want to load up the motion parameters
% [rpfilename]=spm_select('FPList', datadir,'^rp.*\.txt$');
% % RP loaded into RP
% RP=load(rpfilename);
% % normalise RP
% nRP=[];
% for nrp=1:6
%     a=RP(:,nrp);
%     na=2*(a-min(a))/max(a-min(a))-1;
%     nRP(:,nrp)=na;
% end
% R=[nRP];
% R=R-repmat(mean(R),size(R,1),1);
% save(filename,'R');
