%% readscannerpulses.m 
% Validation script for readslices.m
%     Use with either physio_example.smr or for physio_example_PRISMA.smr
%
%________________________________________________________
% readscannerpulses.m
% $Rev: 398 $ $Date: 2024-01-16 15:16:28 +0000 (Tue, 16 Jan 2024) $

%% Spike data-file selection
[fname,fpath,fix] = uigetfile( {'*.smr';'*.mat'}, 'Spike file to open');
if fname == 0; return; end % No file chosen

%% Extract events from scanner channel
switch fix
    case 1 % SMR file via SON library
        fid = fopen([fpath fname]);
        [msg,err] = ferror(fid); if err; error(msg); end
        for chan = 1:20
            [d,h] = SONGetChannel(fid,chan); % get the data & header for channel
            if isempty(h); error('Scanner pulses not found.'); end
            disp( ['Found channel ' num2str(chan) ' ' h.title] )
            if strcmp( h.title, 'scanner' )
                break
            end % if strcmp
        end % for chan
        fclose(fid);
        
    case 2 % MAT file via Spike->Matlab export
        load( [fpath fname] )
        if exist([strrep( strrep(fname,'.smr',''), '.mat','' ) '_Ch1'],'var')
            if strcmpi( eval([strrep( strrep(fname,'.smr',''), '.mat','' ) '_Ch1.title']),'scanner' )
                d = eval([strrep( strrep(fname,'.smr',''), '.mat','' ) '_Ch1.times']);
                
            end % strcmpi
        elseif exist([strrep( strrep(fname,'.smr',''), '.mat','' ) '_scanner'],'var')
        end % if exist
end % switch fix

%% Convert event timestamps into slice numbers & timestamps
[slice, slicet] = readslices( d );

%% Scanning parameters - adjust to suit
nVol   = 125;       % 125 for physio_example.smr & for physio_example_PRISMA.smr
nSlice = 48;
nS = nSlice*nVol;

%% Validation
% assert( length(slice)==nS  ) % expected number of slices found?
assert( all(diff(slice)==1) ) % all slicenumbers increment by 1?
