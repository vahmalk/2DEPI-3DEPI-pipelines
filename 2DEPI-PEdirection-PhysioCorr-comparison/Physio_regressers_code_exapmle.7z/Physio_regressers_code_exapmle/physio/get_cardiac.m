function cpulset=get_cardiac(allscannert,allcpulset)
%
%_______________________________________________________________________
% get_cardiac.m     Eric Feathersone and Chloe Hutton 01/10/07 
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

% Get scanner sessions
if iscell(allscannert)
   nsessions=size(allscannert,2);
else
   nsessions=1;
   tmp=allscannert;
   clear allscannert;
   allscannert{1}=tmp;
end

% Extract data acquired during scanning.
if std(allcpulset)>0        
   % Loop through sessions
   for sessnum=1:nsessions     
      scannert=allscannert{sessnum};    
      % Find pulses starting after scanner has started and before scanner has
      % stopped
      n=find(allcpulset>=scannert(1) & allcpulset<=scannert(end));
      if isempty(n)
          cpulset{sessnum}=[];
          warning('No pulse data was recorded for session %d',sessnum);
      else
          % If possible include pulse measurements just before and just after
          % scanning
          if ( (n(1)-1)>0 && (allcpulset(n(1))-allcpulset(n(1)-1)<2))
             n=[n(1)-1;n];
          end
          if ((n(end)+1)<=size(allcpulset,1) && (allcpulset(n(end)+1)-allcpulset(n(end))<2))
             n=[n;n(end)+1];
          end
          cpulset{sessnum}=allcpulset(n);   
       end % for sessnum=1:nsessions
   end
else
   for sessnum=1:nsessions     
      cpulset{sessnum}=[]; % Empty if no values recorded
   end
   warning('No cardiac pulse data was recorded for any sessions');
end %std(allcpulset) >0    
