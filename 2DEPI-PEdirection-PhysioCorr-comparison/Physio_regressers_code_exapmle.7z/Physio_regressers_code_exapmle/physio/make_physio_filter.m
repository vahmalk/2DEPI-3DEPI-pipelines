function Y=make_physio_filter(pulse)
% Y = make_physio_filter(pulse)
%________________________________________________________
% make_physio_filter.m
% $Rev: 399 $ $Date: 2024-01-16 15:19:24 +0000 (Tue, 16 Jan 2024) $

K        = [];
K.RT     = rsampint;
K.HParam = 10;
K.row    = 1:length(pulse);
Y        = spm_filter(K,pulse);
